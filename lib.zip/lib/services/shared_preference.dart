import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';

/// 🎯 SharedPreferences Wrapper - Complete Version
class SharedPrefs {
  static SharedPreferences? _prefs;

  /// Initialize SharedPreferences (call once in main.dart)
  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // ===========================================================================
  // 🔹 CONSTANTS FOR KEYS
  // ===========================================================================

  // User Authentication & Profile
  static const String keyUserId = 'userId';
  static const String keyUserName = 'userName';
  static const String keyUserRole = 'userRole';
  static const String keySelectedRoleIndex = 'selectedRoleIndex';
  static const String keySelectedRole = 'selectedRole';

  // Challenge Management
  static const String keyHostId = 'hostId';
  static const String keyChallengeId = 'challengeId';
  static const String keyJoinChallengeId = 'joinChallengeId';
  static const String keyAcceptChallengeId = 'acceptChallengeId';
  static const String keyAcceptInviteChallengeId = 'acceptInviteChallengeId';
  static const String keyCurrentChallengeData = 'current_challenge_data';
  static const String keyChallengeResults = 'challenge_results';

  // Game Mode
  static const String keyGameMode = 'game_mode';

  // Industry Selection
  static const String keySelectedIndustryTitle = 'selectedIndustryTitle';
  static const String keySelectedIndustryDesc = 'selectedIndustryDesc';
  static const String keySelectedIndustryIcon = 'selectedIndustryIcon';

  // Campaign Suggestion
  static const String keyCampaignSuggestionName = 'campaignSuggestionName';
  static const String keyCampaignSuggestionDesc = 'campaignSuggestionDesc';
  static const String keyCampaignScenario = 'campaign_scenario';

  // Mission & Initiatives
  static const String keyMissionDescription = 'mission_description';
  static const String keyFirstInitiativeTitle = 'first_initiative_title';
  static const String keyFirstInitiativeDesc = 'first_initiative_desc';
  static const String keySecondInitiativeTitle = 'second_initiative_title';
  static const String keySecondInitiativeDesc = 'second_initiative_desc';

  // Adaptation Data
  static const String keyRevisedKeyResult = 'revised_key_result';
  static const String keyStrategicActions = 'strategic_actions';
  static const String keyAdaptationNotes = 'adaptation_notes';
  static const String keyAdaptationAnalysisData = 'adaptation_analysis_data';

  // Evaluation & Results
  static const String keyFinalOkrEvaluationResult = 'final_okr_evaluation_result';
  static const String keyChallengeEvaluationResult = 'challenge_evaluation_result';
  static const String keyEvaluationScore = 'evaluation_score';
  static const String keyEvaluationDecision = 'evaluation_decision';
  static const String keyEvaluationExplanation = 'evaluation_explanation';

  // Strategy & Objective Selection
  static const String keySelectedStrategy = 'selectedStrategy';
  static const String keySelectedObjective = 'selectedObjective';

  // Certification Data
  static const String keyCertificateEnteredObjectiveTitle = 'certificateEnteredObjective_title';
  static const String keyCertificateEnteredObjectiveDescription = 'certificateEnteredObjective_description';
  static const String keyCertificateEnteredKeyResults = 'certificateEnteredKeyResults';
  static const String keyCertificateEnteredInitiatives = 'certificateEnteredInitiatives';
  static const String keyCertificateScenario = 'certificateScenario';
  static const String keyCertificateSelectedAIStrategy = 'certificateSelectedAIStrategy';
  static const String keyCertificationEvaluationResult = 'certification_evaluation_result';

  // Correct Strategy
  static const String keyCorrectStrategyId = 'correct_strategy_id';

  // Generic save methods
  static Future<void> saveInt(String key, int value) async {
    await _prefs?.setInt(key, value);
  }

  static Future<void> saveString(String key, String value) async {
    await _prefs?.setString(key, value);
  }

  static String? getString(String key) {
    return _prefs?.getString(key);
  }

  static bool containsKey(String key) {
    return _prefs?.containsKey(key) ?? false;
  }

  static Set<String> getAllKeys() {
    return _prefs?.getKeys() ?? {};
  }

  // ===========================================================================
  // 🔹 USER AUTHENTICATION & PROFILE
  // ===========================================================================

  static Future<void> saveUserId(String id) async {
    await _prefs?.setString(keyUserId, id);
  }

  static String? getUserId() {
    return _prefs?.getString(keyUserId);
  }

  static Future<void> saveUserName(String name) async {
    await _prefs?.setString(keyUserName, name);
  }

  static String? getUserName() {
    return _prefs?.getString(keyUserName);
  }

  static Future<void> saveUserRole(String role) async {
    await _prefs?.setString(keyUserRole, role);
  }

  static String? getUserRole() {
    return _prefs?.getString(keyUserRole);
  }

  static Future<void> saveSelectedRoleIndex(int index) async {
    await _prefs?.setInt(keySelectedRoleIndex, index);
  }

  static int getSelectedRoleIndex() {
    return _prefs?.getInt(keySelectedRoleIndex) ?? -1;
  }

  // ===========================================================================
  // 🔹 ROLE SELECTION
  // ===========================================================================

  static Future<void> saveSelectedRole(Map<String, dynamic> role) async {
    final jsonString = jsonEncode(role);
    await _prefs?.setString(keySelectedRole, jsonString);
    print('💾 Saved Selected Role: ${role['titleKey']}');
  }

  static Future<Map<String, dynamic>?> getSelectedRole() async {
    final jsonString = _prefs?.getString(keySelectedRole);
    if (jsonString == null) return null;
    try {
      return Map<String, dynamic>.from(jsonDecode(jsonString));
    } catch (e) {
      print('❌ Error parsing selected role: $e');
      return null;
    }
  }

  static Future<void> clearSelectedRole() async {
    await _prefs?.remove(keySelectedRole);
    print('🧹 Cleared selected role');
  }

  // ===========================================================================
  // 🔹 CHALLENGE MANAGEMENT
  // ===========================================================================

  static Future<void> saveHostId(String id) async {
    await _prefs?.setString(keyHostId, id);
  }

  static String? getHostId() {
    return _prefs?.getString(keyHostId);
  }

  static Future<void> saveChallengeId(String challengeId) async {
    await _prefs?.setString(keyChallengeId, challengeId);
  }

  static Future<String?> getChallengeId() async {
    return _prefs?.getString(keyChallengeId);
  }

  static Future<void> saveJoinChallengeId(String challengeId) async {
    await _prefs?.setString(keyJoinChallengeId, challengeId);
  }

  static String? getJoinChallengeId() {
    return _prefs?.getString(keyJoinChallengeId);
  }

  static Future<void> saveAcceptChallengeId(String challengeId) async {
    await _prefs?.setString(keyAcceptChallengeId, challengeId);
  }

  static String? getAcceptChallengeId() {
    return _prefs?.getString(keyAcceptChallengeId);
  }

  static Future<void> saveAcceptInviteChallengeId(String challengeId) async {
    await _prefs?.setString(keyAcceptInviteChallengeId, challengeId);
  }

  static String? getAcceptInviteChallengeId() {
    return _prefs?.getString(keyAcceptInviteChallengeId);
  }

  // ===========================================================================
  // 🔹 GAME MODE
  // ===========================================================================

  static Future<void> saveGameMode(String gameMode) async {
    await _prefs?.setString(keyGameMode, gameMode);
  }

  static String? getGameMode() {
    return _prefs?.getString(keyGameMode);
  }

  static Future<void> clearGameMode() async {
    await _prefs?.remove(keyGameMode);
  }

  // ===========================================================================
  // 🔹 INDUSTRY SELECTION
  // ===========================================================================

  static Future<void> saveSelectedIndustry(Map<String, dynamic> industry) async {
    await _prefs?.setString(keySelectedIndustryTitle, industry['titleKey'].toString());
    await _prefs?.setString(keySelectedIndustryDesc, industry['descriptionKey'].toString());
    await _prefs?.setString(keySelectedIndustryIcon, _iconToString(industry['icon']));
  }

  static Map<String, dynamic>? getSelectedIndustry() {
    final title = _prefs?.getString(keySelectedIndustryTitle);
    final desc = _prefs?.getString(keySelectedIndustryDesc);
    final iconName = _prefs?.getString(keySelectedIndustryIcon);

    if (title == null) return null;

    return {
      'titleKey': title,
      'descriptionKey': desc ?? '',
      'icon': _stringToIcon(iconName),
    };
  }

  static Future<void> clearSelectedIndustry() async {
    await _prefs?.remove(keySelectedIndustryTitle);
    await _prefs?.remove(keySelectedIndustryDesc);
    await _prefs?.remove(keySelectedIndustryIcon);
  }

  // ===========================================================================
  // 🔹 CAMPAIGN SUGGESTION (AI Generated)
  // ===========================================================================

  static Future<void> saveCampaignSuggestion(String name, String description) async {
    await _prefs?.setString(keyCampaignSuggestionName, name);
    await _prefs?.setString(keyCampaignSuggestionDesc, description);
  }

  static String? getCampaignSuggestionName() {
    return _prefs?.getString(keyCampaignSuggestionName);
  }

  static String? getCampaignSuggestionDescription() {
    return _prefs?.getString(keyCampaignSuggestionDesc);
  }

  static Future<void> saveCampaignScenario(String scenario) async {
    await _prefs?.setString(keyCampaignScenario, scenario);
  }

  static String? getCampaignScenario() {
    return _prefs?.getString(keyCampaignScenario);
  }

  static Future<void> clearCampaignSuggestion() async {
    await _prefs?.remove(keyCampaignSuggestionName);
    await _prefs?.remove(keyCampaignSuggestionDesc);
  }

  // ===========================================================================
  // 🔹 STRATEGY SELECTION
  // ===========================================================================

  static Future<void> saveSelectedStrategy(Map<String, dynamic> strategy) async {
    final jsonString = jsonEncode(strategy);
    await _prefs?.setString(keySelectedStrategy, jsonString);
    print('💾 Saved Selected Strategy: ${strategy['title']}');
  }

  static Future<Map<String, dynamic>?> getSelectedStrategy() async {
    final jsonString = _prefs?.getString(keySelectedStrategy);
    if (jsonString == null) return null;
    try {
      return Map<String, dynamic>.from(jsonDecode(jsonString));
    } catch (e) {
      print('❌ Error parsing selected strategy: $e');
      return null;
    }
  }

  static Future<void> clearSelectedStrategy() async {
    await _prefs?.remove(keySelectedStrategy);
    print('🧹 Cleared selected strategy');
  }

  // ===========================================================================
  // 🔹 OBJECTIVE SELECTION
  // ===========================================================================

  static Future<void> saveSelectedObjective(Map<String, dynamic> objective) async {
    final jsonString = jsonEncode(objective);
    await _prefs?.setString(keySelectedObjective, jsonString);
    print('💾 Saved Selected Objective: ${objective['title']}');
  }

  static Future<Map<String, dynamic>?> getSelectedObjective() async {
    final jsonString = _prefs?.getString(keySelectedObjective);
    if (jsonString == null) return null;
    try {
      return Map<String, dynamic>.from(jsonDecode(jsonString));
    } catch (e) {
      print('❌ Error parsing selected objective: $e');
      return null;
    }
  }

  static Future<void> clearSelectedObjective() async {
    await _prefs?.remove(keySelectedObjective);
    print('🧹 Cleared selected objective');
  }

  // ===========================================================================
  // 🔹 MISSION & INITIATIVES
  // ===========================================================================

  static Future<void> saveMissionDescription(String description) async {
    await _prefs?.setString(keyMissionDescription, description);
  }

  static String? getMissionDescription() {
    return _prefs?.getString(keyMissionDescription);
  }

  static Future<void> clearMissionDescription() async {
    await _prefs?.remove(keyMissionDescription);
  }

  static Future<void> saveInitiatives({
    required String firstTitle,
    required String firstDesc,
    required String secondTitle,
    required String secondDesc,
  }) async {
    await _prefs?.setString(keyFirstInitiativeTitle, firstTitle);
    await _prefs?.setString(keyFirstInitiativeDesc, firstDesc);
    await _prefs?.setString(keySecondInitiativeTitle, secondTitle);
    await _prefs?.setString(keySecondInitiativeDesc, secondDesc);
  }

  static Map<String, String> getInitiatives() {
    return {
      'firstTitle': _prefs?.getString(keyFirstInitiativeTitle) ?? '',
      'firstDesc': _prefs?.getString(keyFirstInitiativeDesc) ?? '',
      'secondTitle': _prefs?.getString(keySecondInitiativeTitle) ?? '',
      'secondDesc': _prefs?.getString(keySecondInitiativeDesc) ?? '',
    };
  }

  static Future<void> clearInitiatives() async {
    await _prefs?.remove(keyFirstInitiativeTitle);
    await _prefs?.remove(keyFirstInitiativeDesc);
    await _prefs?.remove(keySecondInitiativeTitle);
    await _prefs?.remove(keySecondInitiativeDesc);
  }

  // ===========================================================================
  // 🔹 ADAPTATION DATA
  // ===========================================================================

  static Future<void> saveAdaptationData({
    required String revisedKeyResult,
    required String strategicActions,
    String adaptationNotes = '',
  }) async {
    await _prefs?.setString(keyRevisedKeyResult, revisedKeyResult);
    await _prefs?.setString(keyStrategicActions, strategicActions);
    await _prefs?.setString(keyAdaptationNotes, adaptationNotes);
  }

  static Map<String, String> getAdaptationData() {
    return {
      'revisedKeyResult': _prefs?.getString(keyRevisedKeyResult) ?? '',
      'strategicActions': _prefs?.getString(keyStrategicActions) ?? '',
      'adaptationNotes': _prefs?.getString(keyAdaptationNotes) ?? '',
    };
  }

  static Future<void> saveAdaptationAnalysisData(Map<String, dynamic> data) async {
    try {
      final jsonString = jsonEncode(data);
      await _prefs?.setString(keyAdaptationAnalysisData, jsonString);
      print('💾 Saved adaptation analysis data');
    } catch (e) {
      print('❌ Error saving adaptation analysis data: $e');
    }
  }

  static Future<Map<String, dynamic>?> getAdaptationAnalysisData() async {
    try {
      final jsonString = _prefs?.getString(keyAdaptationAnalysisData);
      if (jsonString != null) {
        return jsonDecode(jsonString) as Map<String, dynamic>;
      }
      return null;
    } catch (e) {
      print('❌ Error getting adaptation analysis data: $e');
      return null;
    }
  }

  static Future<void> clearAdaptationData() async {
    await _prefs?.remove(keyRevisedKeyResult);
    await _prefs?.remove(keyStrategicActions);
    await _prefs?.remove(keyAdaptationNotes);
    await _prefs?.remove(keyAdaptationAnalysisData);
  }

  // ===========================================================================
  // 🔹 EVALUATION & RESULTS
  // ===========================================================================

  static Future<void> saveFinalOkrEvaluationResult(Map<String, dynamic> result) async {
    final jsonString = jsonEncode(result);
    await _prefs?.setString(keyFinalOkrEvaluationResult, jsonString);
  }

  static Map<String, dynamic>? getFinalOkrEvaluationResult() {
    final jsonString = _prefs?.getString(keyFinalOkrEvaluationResult);
    if (jsonString == null) return null;
    try {
      return jsonDecode(jsonString);
    } catch (e) {
      return null;
    }
  }

  static Future<void> saveChallengeEvaluationResult(Map<String, dynamic> result) async {
    final jsonString = jsonEncode(result);
    await _prefs?.setString(keyChallengeEvaluationResult, jsonString);
  }

  static Map<String, dynamic>? getChallengeEvaluationResult() {
    final jsonString = _prefs?.getString(keyChallengeEvaluationResult);
    if (jsonString == null) return null;
    try {
      return jsonDecode(jsonString);
    } catch (e) {
      return null;
    }
  }

  static Future<void> saveEvaluationSummary({
    required int score,
    required String decision,
    required String explanation,
  }) async {
    await _prefs?.setInt(keyEvaluationScore, score);
    await _prefs?.setString(keyEvaluationDecision, decision);
    await _prefs?.setString(keyEvaluationExplanation, explanation);
  }

  static Map<String, dynamic> getEvaluationSummary() {
    return {
      'score': _prefs?.getInt(keyEvaluationScore) ?? 0,
      'decision': _prefs?.getString(keyEvaluationDecision) ?? 'Pending',
      'explanation': _prefs?.getString(keyEvaluationExplanation) ?? 'No analysis available',
    };
  }

  static Future<void> saveChallengeResults(List<Map<String, dynamic>> results) async {
    await _prefs?.setString(keyChallengeResults, jsonEncode(results));
  }

  static Future<List<Map<String, dynamic>>?> getChallengeResults() async {
    final resultsJson = _prefs?.getString(keyChallengeResults);
    if (resultsJson == null) return null;

    try {
      final List<dynamic> resultsList = jsonDecode(resultsJson);
      return resultsList.map((item) => Map<String, dynamic>.from(item)).toList();
    } catch (e) {
      print('❌ Error parsing challenge results: $e');
      return null;
    }
  }

  static Future<void> saveCurrentChallengeData(Map<String, dynamic> data) async {
    await _prefs?.setString(keyCurrentChallengeData, jsonEncode(data));
  }

  static Future<Map<String, dynamic>?> getCurrentChallengeData() async {
    final dataJson = _prefs?.getString(keyCurrentChallengeData);
    if (dataJson == null) return null;

    try {
      return Map<String, dynamic>.from(jsonDecode(dataJson));
    } catch (e) {
      print('❌ Error parsing current challenge data: $e');
      return null;
    }
  }

  static Future<void> clearEvaluationData() async {
    await _prefs?.remove(keyFinalOkrEvaluationResult);
    await _prefs?.remove(keyChallengeEvaluationResult);
    await _prefs?.remove(keyEvaluationScore);
    await _prefs?.remove(keyEvaluationDecision);
    await _prefs?.remove(keyEvaluationExplanation);
  }

  // ===========================================================================
  // 🔹 CERTIFICATION DATA
  // ===========================================================================

  static Future<void> saveCertificateObjective(String title, String description) async {
    await _prefs?.setString(keyCertificateEnteredObjectiveTitle, title);
    await _prefs?.setString(keyCertificateEnteredObjectiveDescription, description);
    print('💾 Saved Objective: $title');
  }

  static Map<String, String> getCertificateObjective() {
    return {
      'title': _prefs?.getString(keyCertificateEnteredObjectiveTitle) ?? '',
      'description': _prefs?.getString(keyCertificateEnteredObjectiveDescription) ?? '',
    };
  }

  static Future<void> saveCertificateKeyResults(List<Map<String, String>> keyResults) async {
    final jsonString = jsonEncode(keyResults);
    await _prefs?.setString(keyCertificateEnteredKeyResults, jsonString);
    print('💾 Saved ${keyResults.length} Key Results');
  }

  static List<Map<String, String>> getCertificateKeyResults() {
    final jsonString = _prefs?.getString(keyCertificateEnteredKeyResults) ?? '[]';
    try {
      final List<dynamic> jsonList = jsonDecode(jsonString);
      return jsonList.map((item) => Map<String, String>.from(item)).toList();
    } catch (e) {
      print('❌ Error parsing key results: $e');
      return [];
    }
  }

  static Future<void> saveCertificateInitiatives(List<Map<String, String>> initiatives) async {
    final jsonString = jsonEncode(initiatives);
    await _prefs?.setString(keyCertificateEnteredInitiatives, jsonString);
    print('💾 Saved ${initiatives.length} Initiatives');
  }

  static List<Map<String, String>> getCertificateInitiatives() {
    final jsonString = _prefs?.getString(keyCertificateEnteredInitiatives) ?? '[]';
    try {
      final List<dynamic> jsonList = jsonDecode(jsonString);
      return jsonList.map((item) => Map<String, String>.from(item)).toList();
    } catch (e) {
      print('❌ Error parsing initiatives: $e');
      return [];
    }
  }

  static Future<void> saveCertificateScenario(String scenario) async {
    await _prefs?.setString(keyCertificateScenario, scenario);
    print('💾 Saved Scenario: ${scenario.length} characters');
  }

  static String getCertificateScenario() {
    return _prefs?.getString(keyCertificateScenario) ??
        'A multinational technology company facing declining market share and internal coordination challenges across 3 departments: Sales, Product, and Operations.';
  }

  static Future<void> saveCertificateSelectedAIStrategy(Map<String, dynamic> strategy) async {
    final jsonString = jsonEncode(strategy);
    await _prefs?.setString(keyCertificateSelectedAIStrategy, jsonString);
    print('💾 Saved Selected Strategy: ${strategy['title']}');
  }

  static Map<String, dynamic> getCertificateSelectedAIStrategy() {
    final jsonString = _prefs?.getString(keyCertificateSelectedAIStrategy) ?? '{}';
    try {
      final Map<String, dynamic> strategy = jsonDecode(jsonString);
      return strategy;
    } catch (e) {
      print('❌ Error parsing selected strategy: $e');
      return {};
    }
  }

  static Future<void> saveCertificationEvaluationResult(Map<String, dynamic> result) async {
    final jsonString = jsonEncode(result);
    await _prefs?.setString(keyCertificationEvaluationResult, jsonString);
    print('💾 Saved certification evaluation result');
  }

  static Map<String, dynamic>? getCertificationEvaluationResult() {
    final jsonString = _prefs?.getString(keyCertificationEvaluationResult);
    if (jsonString == null) return null;
    try {
      return jsonDecode(jsonString);
    } catch (e) {
      print('❌ Error parsing certification evaluation result: $e');
      return null;
    }
  }

  static Future<void> clearCertificationEvaluationResult() async {
    await _prefs?.remove(keyCertificationEvaluationResult);
    print('🧹 Cleared certification evaluation result');
  }

  static Future<void> clearCertificateData() async {
    await _prefs?.remove(keyCertificateEnteredObjectiveTitle);
    await _prefs?.remove(keyCertificateEnteredObjectiveDescription);
    await _prefs?.remove(keyCertificateEnteredKeyResults);
    await _prefs?.remove(keyCertificateEnteredInitiatives);
    await _prefs?.remove(keyCertificateScenario);
    await _prefs?.remove(keyCertificateSelectedAIStrategy);
    print('🧹 Cleared all certificate data');
  }

  static bool hasCertificateData() {
    return getCertificateObjective()['title']?.isNotEmpty == true &&
        getCertificateKeyResults().isNotEmpty &&
        getCertificateInitiatives().isNotEmpty;
  }

  static Future<bool> verifyAllCertificateData() async {
    final objective = getCertificateObjective();
    final keyResults = getCertificateKeyResults();
    final initiatives = getCertificateInitiatives();
    final scenario = getCertificateScenario();
    final strategy = getCertificateSelectedAIStrategy();

    print('🔍 VERIFYING ALL CERTIFICATE DATA:');
    print('🎯 Objective: ${objective['title']?.isNotEmpty == true ? "✅" : "❌"} ${objective['title']}');
    print('📊 Key Results: ${keyResults.length >= 3 ? "✅" : "❌"} ${keyResults.length}/3');
    print('🚀 Initiatives: ${initiatives.length >= 2 ? "✅" : "❌"} ${initiatives.length}/2');
    print('📖 Scenario: ${scenario.isNotEmpty ? "✅" : "❌"} ${scenario.length} chars');
    print('🎯 Strategy: ${strategy.isNotEmpty ? "✅" : "❌"} ${strategy['title']}');

    return objective['title']?.isNotEmpty == true &&
        keyResults.length >= 3 &&
        initiatives.length >= 2 &&
        scenario.isNotEmpty &&
        strategy.isNotEmpty;
  }

  static void printCertificateData() {
    print('📋 CERTIFICATION DATA SUMMARY:');
    print('🎯 Objective: ${getCertificateObjective()}');
    print('📊 Key Results: ${getCertificateKeyResults().length} items');
    print('🚀 Initiatives: ${getCertificateInitiatives().length} items');
    print('📖 Scenario: ${getCertificateScenario().length} characters');
    print('🎯 Selected Strategy: ${getCertificateSelectedAIStrategy()['title'] ?? 'None'}');
  }

  // ===========================================================================
  // 🔹 CORRECT STRATEGY
  // ===========================================================================

  static Future<void> saveCorrectStrategyId(int strategyId) async {
    await _prefs?.setInt(keyCorrectStrategyId, strategyId);
  }

  static int getCorrectStrategyId() {
    return _prefs?.getInt(keyCorrectStrategyId) ?? 0;
  }

  // ===========================================================================
  // 🔹 ICON CONVERSION HELPERS
  // ===========================================================================

  static String _iconToString(IconData? icon) {
    if (icon == Icons.computer) return 'computer';
    if (icon == Icons.account_balance) return 'finance';
    if (icon == Icons.local_hospital) return 'health';
    if (icon == Icons.flash_on) return 'energy';
    if (icon == Icons.local_shipping) return 'logistics';
    if (icon == Icons.account_balance_outlined) return 'public';
    if (icon == Icons.storefront) return 'retail';
    if (icon == Icons.phone_android) return 'telecom';
    if (icon == Icons.agriculture) return 'agriculture';
    return 'default';
  }

  static IconData _stringToIcon(String? iconName) {
    switch (iconName) {
      case 'computer':
        return Icons.computer;
      case 'finance':
        return Icons.account_balance;
      case 'health':
        return Icons.local_hospital;
      case 'energy':
        return Icons.flash_on;
      case 'logistics':
        return Icons.local_shipping;
      case 'public':
        return Icons.account_balance_outlined;
      case 'retail':
        return Icons.storefront;
      case 'telecom':
        return Icons.phone_android;
      case 'agriculture':
        return Icons.agriculture;
      default:
        return Icons.work;
    }
  }

  // ===========================================================================
  // 🔹 UTILITY METHODS
  // ===========================================================================

  static Future<void> clearAll() async {
    await _prefs?.clear();
  }

  // Clear all game session data (keep user auth)
  static Future<void> clearGameSessionData() async {
    print('🧹 Clearing all game session data for fresh start...');

    // Clear strategy selection
    await clearSelectedStrategy();

    // Clear objective selection
    await clearSelectedObjective();

    // Clear role selection
    await clearSelectedRole();
    await _prefs?.remove(keySelectedRoleIndex);

    // Clear industry selection
    await clearSelectedIndustry();

    // Clear mission & initiatives
    await clearMissionDescription();
    await clearInitiatives();

    // Clear adaptation data
    await clearAdaptationData();
    // await clearAdaptationAnalysisData();

    // Clear evaluation data
    await clearEvaluationData();

    // Clear campaign data
    await clearCampaignSuggestion();
    await _prefs?.remove(keyCampaignScenario);

    // Clear challenge data
    await _prefs?.remove(keyCurrentChallengeData);
    await _prefs?.remove(keyChallengeResults);

    // Clear certification data
    await clearCertificateData();
    await clearCertificationEvaluationResult();

    print('✅ Game session data cleared successfully');
  }
}