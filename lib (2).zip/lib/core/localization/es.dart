final Map<String, String> es = {


  "ready_for_solo_mode": "¿Listo para el modo Solo?",
  "ready_for_team_mode": "¿Listo para el modo Equipo?",
  "ready_for_campaign_mode": "¿Listo para el modo Campaña?",
  "solo_mode_description": "Desafíate y mejora tus habilidades individualmente con nuestras funciones de modo solo.",
  "team_mode_description": "Colabora con los miembros de tu equipo y alcanza objetivos comunes.",
  "campaign_mode_description": "Embárcate en un emocionante viaje con misiones estructuradas y desafíos progresivos.",

  "solo_mode_level_1": "Acceso al Nivel 1 del modo Solo",
  "ai_feedback_per_day": "Retroalimentación IA (3 por día)",
  "certified_challenge_per_day": "Desafío certificado (1 por día)",
  "limited_badges": "Colección de insignias limitada",
  "full_solo_mode": "Acceso completo al modo Solo",
  "weekly_missions": "Misiones semanales",
  "ai_tips_debrief": "Consejos y informe IA",
  "xp_tracking": "Seguimiento de XP",
  "community_leaderboard": "Tabla de clasificación comunitaria",
  "bonus_mode": "Acceso al modo Bonus",
  "all_navigator_plus_features": "Todas las funciones de Navigator+",
  "official_certificate": "Certificado oficial",
  "performance_reports": "Informes de rendimiento",
  "monthly_live_coaching": "Entrenamiento en vivo mensual",
  "exclusive_badge_sets": "Conjuntos de insignias exclusivas",

  "level_1_access": "Acceso Nivel 1",
  "level_2_access": "Acceso Nivel 2",
  "level_3_access": "Acceso Nivel 3",
  "single_user": "Usuario único",
  "multiple_users": "Múltiples usuarios",


  "ready_for_solo_mode": "¿Listo para el modo Solo?",
  "ready_for_team_mode": "¿Listo para el modo Equipo?",
  "ready_for_campaign_mode": "¿Listo para el modo Campaña?",
  "solo_mode_description": "Desafíate y mejora tus habilidades individualmente",
  "team_mode_description": "Trabaja junto con tu equipo para lograr objetivos comunes",
  "campaign_mode_description": "Participa en misiones estructuradas con dificultad progresiva",
  'select':                          'Seleccionar',
  'role':                            'Rol',
  'welcome_navigator':               'Bienvenido, Navegante',
  'company_crisis_description':      'Tu empresa está enfrentando una crisis. Navega por los desafíos, toma decisiones estratégicas y lidera a tu equipo hacia el éxito.',
  'choose_role_instruction':         'Elige tu rol para comenzar el recorrido',
  'select_your_role':                'Selecciona tu rol',
  'select_continue':                 'Continuar',
  'first_time_playing':              '¿Es tu primera vez jugando?',
  'watch_tutorial':                  'Ver tutorial',
  'watch_tutorial_video':            'Ver video del tutorial',
  'select_role':                     'Seleccionar rol',

  'Choose':                          'Elegir',
  'Your Industry':                   'Tu Industria',
  'search_industry':                 'Buscar industria...',
  'choose_industry':                 'Elegir industria',
  'welcome_role':                    'Bienvenido, @role',

  'choose':                          'Elegir',
  'objective':                       'Objetivo',
  'try_again_with_different':        'Intentar de nuevo',
  'modify':                          'Modificar',
  'select_different_objective_retry':'Selecciona un objetivo diferente e inténtalo de nuevo',
  'select_new_objective_for_challenge': 'Selecciona un nuevo objetivo para adaptarte al desafío actual',
  'select_one_objective':            'Selecciona un objetivo para guiar tu estrategia',
  'save_changes':                    'Guardar cambios',
  'complete_selection':              'Completar selección',
  'selected_strategy':               'Estrategia seleccionada',
  'choose_your_objective':           'Elige tu objetivo',
  'retry_attempt':                   'Intento de reintento',
  'adapting_to_challenge':           'Adaptándose al desafío',
  'no_objectives_available':         'No hay objetivos disponibles',

  'tap_to_reveal_strategy':          'Toca para revelar la estrategia',
  'draw_new_strategy':               'Sacar nueva estrategia',
  // APP NAME & LOGOS
  "app_name": "OKR Navigator",
  "okr_nav": "OKR'Nav",
  "okr_hau": "OKR'hau",
  "okr_now": "OKR'Now",
  "okr_logo": "Logo OKR",
  "bottom_logo": "Logo de la app",
  "progress_warning": "Advertencia de Progreso",
  "progress_warning_desc": "Tu progreso actual se perderá. ¿Estás seguro de que quieres ir a casa?",
  "cancel": "Cancelar",
  "yes_go_home": "Sí, Ir a Casa",
  "success": "Éxito",
  "redirected_home": "Redirigido a la pantalla de inicio",
  // Feedback Screen
  'choose_industry': 'Elige tu industria',
  'strategic_initiative': 'Iniciativa estratégica',
  'add_initiatives_to_continue': 'Agrega iniciativas para continuar',
  "okr": "OKR",
  "feedback": "Retroalimentación",
  "no_feedback_data_available": "No hay datos de retroalimentación disponibles",
  "continue": "Continuar",
  "level_completed": "¡Nivel Completado!",
  "organization_completed": "¡Organización ${0} completada!",
  "score": "Puntuación: ${0}",
  "strategy_alignment": "Alineación Estratégica",
  "objective_alignment": "Alineación de Objetivos",
  "key_result_quality": "Calidad de Resultados Clave",
  "okr_evaluation_feedback": "Retroalimentación de Evaluación OKR",
  
  // Language Screen
  "choose_language": "Elige tu idioma",
  "language_subtitle": "Selecciona tu idioma preferido para la aplicación",
  "continue_button": "Continuar",
  "english": "Inglés",
  "spanish": "Español",
  "french": "Francés",
  "german": "Alemán",
  "italian": "Italiano",
  "afrikaans": "Afrikáans",
  
  // Home Screen
  "certificate": "Certificado",
  
  // Scoreboard Screen
  "your": "Tu",
  "scoreboard": "Tablero de Puntuación",
  "show_personal_achievements": "Mostrar Logros Personales",
  "I'm ranked #3 in Strategic Agility this week!": "¡Estoy clasificado #3 en Agilidad Estratégica esta semana!",
  
  // Team Initiative Screen
  "suggestion": "Sugerencia",
  "of_initiatives": "de Iniciativas",
  "error": "Error",
  
  // Personal Achievements Screen
  "personal": "Personal",
  "achievements": "Logros",
  "strategic_architect": "Arquitecto Estratégico",
  "level": "Nivel {{num}}",
  "points": "Puntos",
  
  // Final Test Certification Screen
  "final_test": "Examen Final",
  "certification": "Certificación",
  "ai_evaluation_progress": "Progreso de Evaluación IA",
  "test_completed": "Prueba Completada",
  
  // Mini Simulation Screen
  "mini_simulation": "Mini Simulación",
  "refine_strategy_address_challenge": "Refina tu estrategia para abordar el desafío",
  "solve_scenario_minutes": "Resuelve este escenario en solo unos minutos",
  
  // Game Complete Screen
  "game": "Juego",
  "complete": "Completado",

  // AUTHENTICATION & ONBOARDING
  "dont_have_account": "¿No tienes una cuenta?",
  "already_have_account": "¿Ya tienes una cuenta?",
  "alreadyNavigator": "¿Ya eres Navegador?",
  "login": "Iniciar sesión",
  "register": "Registrarse",
  "logout": "Cerrar sesión",
  "sign_in": "Iniciar sesión",
  "sign_up": "Registrarse",
  "want_a_navigator": "¿Quieres un Navegador?",
  "sign_up_role": "Regístrate para asumir el papel de Navegador estratégico.",
  "signUpRole": "Regístrate para asumir el papel de Navegador estratégico.",
  "enter_arena": "Entrar en la Arena OKR",
  "rejoin_operation": "Reanudar la Operación",
  "strategy_awaits": "Tu estrategia te espera. Inicia sesión para continuar.",
  "remember_me": "Recordarme",
  "forget_password": "¿Olvidaste tu contraseña?",
  "password_reset_coming": "¡La función de restablecer contraseña llegará pronto!",
  "email": "Ingresar correo electrónico",
  "enter_email": "Ingresar dirección de correo",
  "password": "Ingresar contraseña",
  "enter_password": "Ingresar contraseña",
  "confirm_password": "Confirmar contraseña",
  "enter_confirm_password": "Confirmar contraseña",
  "enter_name": "Ingresar nombre",
  "enter_phone": "Ingresar número de teléfono",

  // FORM VALIDATION
  "email_required": "El correo es obligatorio",
  "invalid_email": "Por favor, introduce un correo válido",
  "password_required": "La contraseña es obligatoria",
  "password_length": "La contraseña debe tener al menos 6 caracteres",
  "password_mismatch": "Las contraseñas no coinciden",
  "name_required": "El nombre es obligatorio",
  "phoneRequired": "El teléfono es obligatorio",
  "invalidPhone": "Por favor, introduce un teléfono válido",

  // AUTH MESSAGES
  "invalid_credentials": "Correo o contraseña incorrectos",
  "login_failed": "Error al iniciar sesión. Inténtalo de nuevo.",
  "login_successful": "¡Inicio de sesión exitoso!",
  "registration_successful": "¡Registro exitoso!",
  "registration_failed": "Error de registro. Inténtalo de nuevo.",
  "email_not_found": "Correo no encontrado",
  "invalid_password": "Contraseña inválida",

  // LANGUAGE & LOCALIZATION
  "select_language": "Seleccionar idioma",
  "choose_language": "Elige tu idioma preferido",
  "currentLanguage": "Idioma actual",
  "english": "Inglés",
  "spanish": "Español",
  "french": "Francés",
  "german": "Alemán",
  "italian": "Italiano",
  "russian": "Ruso",

  // COMMON BUTTONS & STATES
  "continue": "Continuar",
  "next": "Siguiente",
  "back": "Atrás",
  "skip": "Saltar",
  "done": "Hecho",
  "loading": "Cargando...",
  "retry": "Reintentar",
  "no_data": "No hay datos disponibles",
  "coming_soon": "¡Esta función estará disponible pronto!",
  "ok": "OK",
  "cancel": "Cancelar",

  // HOME & DASHBOARD
  "home": "Inicio",
  "profile": "Perfil",
  "settings": "Configuraciones",
  "notifications": "Notificaciones",
  "dashboard": "Panel de control",

  // STRATEGY SCREENS
  "strategy": "Estrategia",
  "draw_strategy": "Dibuja tu estrategia",
  "draw_strategy_subtitle": "Dibuja tu tarjeta de estrategia y da el primer paso\npara remodelar el futuro de la empresa.",
  "strategy_tips": "Consejos de estrategia",
  "strategic_tips": "Consejos estratégicos",
  "draw_new_strategy": "Dibujar nueva estrategia",
  "tap_to_reveal_strategy": "Toca para revelar tu estrategia",
  "strategy_intro": "Acabas de entrar en una empresa en crisis. Cada decisión puede cambiar su futuro.",
  "strategy_tip1": "Desarrollar e introducir productos innovadores",
  "strategy_tip2": "Enfocarse en expandirse a mercados no explotados para impulsar el crecimiento sostenible y aumentar la participación en el mercado.",

  // AI STRATEGIC ANALYSIS
  "ai_strategic_analysis": "Análisis estratégico de IA",
  "submit_initiatives_ai_analysis": "Enviar tus iniciativas para análisis de IA",
  "feedback_will_appear_here": "Los comentarios aparecerán aquí",
  "ai_feedback_per_day": "1 comentario de IA por día",
  "ai_tips_debrief": "Consejos de IA y revisión",
  "AI has analyzed your initiatives and found them highly relevant! 🚀":
  "¡La IA ha analizado tus iniciativas y las ha encontrado muy relevantes! 🚀",

  // OBJECTIVES & KEY RESULTS
  "objective": "Objetivo",
  "selected_objective": "Objetivo seleccionado",
  "objective_description":
  "''Desarrollar e introducir productos innovadores\n"
      "adaptados a las nuevas demandas del mercado en 15\n"
      "meses''",
  "select_key_results": "Seleccionar resultados clave",
  "choose_3_outcomes": "Elige 3 resultados medibles. Construye tu\nconstelación de métricas de éxito",
  "complete_selection": "Completar selección",
  "key_results_selected": "Resultados clave seleccionados",
  "all_key_results_selected": "¡Todos los resultados clave seleccionados!",
  "one_more_needed": "Falta 1 más",
  "more_needed": "faltan más",

  // INDUSTRY SELECTION
  'Select Industry': 'Seleccionar industria',
  'Please select an industry to continue': 'Por favor selecciona una industria para continuar',
  'Selected': 'Seleccionado',
  'You selected:': 'Has seleccionado:',
  'Technology': 'Tecnología',
  'Software, SaaS, Digital Products': 'Software, SaaS, Productos digitales',
  'Finance & Banking': 'Finanzas y Banca',
  'Investment, Insurance, Fintech': 'Inversión, Seguros, Fintech',
  'Healthcare': 'Salud',
  'Medical, Pharma, Health Tech': 'Médico, Farmacéutico, Tecnología de la Salud',

  // GAME MODES
  "game_mode": "Modo de juego",
  "unknown_mode": "Modo desconocido",
  "solo": "Individual",
  "Solo": "Individual",
  "Team": "Equipo",
  "Campaign": "Campaña",
  "bonus_mode": "Modo bonus",
  "navigator": "Navegador",
  "navigator_plus": "Navegador+",
  "master_navigation": "Navegación maestra",

  // ONBOARDING & MISC SCREENS
  "welcome_navigator": "¡Bienvenido, Navegador!",
  "splash1_subtitle": "Has sido reclutado para una misión de alto riesgo. "
      "Una de nuestras empresas más importantes enfrenta una crisis estratégica "
      "y necesita tu liderazgo para cambiar las cosas.",
  "splash2_title": "La empresa está en problemas",
  "splash2_subtitle": "La productividad está disminuyendo. Los objetivos están desalineados. "
      "El equipo está perdiendo el enfoque. Solo tú tienes las habilidades "
      "para aportar claridad, dirección y resultados.",

  // JOURNEY & MAP
  "journey": "Viaje",
  "map": "Mapa",
  "show_less": "Mostrar menos",
  "show_progress": "Mostrar progreso",
  "complete": "Completado",
  "back_home": "Volver al inicio",

  // ERRORS
  "error": "Error",
  "fill_initiatives": "Por favor, completa ambas iniciativas antes de enviar.",
  "initiatives_submitted": "✅ Iniciativas enviadas para análisis de IA.",
  'show_personal_achievements': 'Show Personal Achievements',
};
