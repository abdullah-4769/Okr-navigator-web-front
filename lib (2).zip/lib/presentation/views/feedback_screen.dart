// lib/presentation/views/feedback/feedback_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:game_app/presentation/routes/app_routes.dart';
import 'package:get/get.dart';
import 'package:game_app/generated/models/responses/key_results/key_results_response.dart'
as key_result_models;
import '../../generated/models/requests/campaign_mode/feedback_evaluation_model.dart';
import '../../services/shared_preference.dart';
import '../../view_model/campaign_mode/feedback_evaluation_view_model.dart';
import '../widgets/Website/desktop_appbar.dart';
import '../widgets/campaign_progress_service.dart';
import '../widgets/custom_button2.dart';
import '../widgets/custom_home_navbar.dart';
import '../widgets/custom_svg.dart';
import '../widgets/game_complete_widgets/custom_score_card.dart';
import '../widgets/screens_unique_parts/custom_background.dart';
import '../widgets/screens_unique_parts/custom_header.dart';

class FeedbackScreen extends StatelessWidget {
  final List<key_result_models.KeyResult> selectedKeyResults;

  const FeedbackScreen({super.key, required this.selectedKeyResults});

  // ── Adaptive font helper ───────────────────────────────────────────────────
  // Returns plain logical px on desktop/tablet, .sp on mobile.
  // Call after you know screenWidth.
  static double _fs(double screenWidth, double mobile,
      {double? tablet, double? desktop}) {
    if (screenWidth >= 1024) return desktop ?? tablet ?? mobile - 2;
    if (screenWidth >= 768) return tablet ?? mobile - 1;
    return mobile.sp;
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = Get.put(FeedbackEvaluationViewModel());

    WidgetsBinding.instance.addPostFrameCallback((_) {
      viewModel.evaluateSelectedKeyResults(selectedKeyResults);
    });

    return LayoutBuilder(
      builder: (context, constraints) {
        final double screenWidth = constraints.maxWidth;
        final bool isMobile = screenWidth < 768;

        return isMobile
            ? _buildMobileLayout(context, viewModel, screenWidth)
            : _buildDesktopLayout(context, viewModel, screenWidth);
      },
    );
  }

  // ── MOBILE ─────────────────────────────────────────────────────────────────
  Widget _buildMobileLayout(BuildContext context,
      FeedbackEvaluationViewModel viewModel, double screenWidth) {
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      body: CustomBackground(
        child: Stack(
          children: [
            // Scrollable content
            Padding(
              padding: EdgeInsets.only(bottom: 80.h),
              child: SingleChildScrollView(
                padding:
                EdgeInsets.symmetric(vertical: 14.h, horizontal: 16.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomHeader(
                      title: 'okr'.tr,
                      highlightedText: 'feedback'.tr,
                      onBackTap: () => Get.back(),
                    ),
                    SizedBox(height: 20.h),
                    _buildContent(viewModel, screenWidth),
                  ],
                ),
              ),
            ),

            // Sticky bottom button
            Positioned(
              left: 16.w,
              right: 16.w,
              bottom: 16.h,
              child: _buildContinueButton(screenWidth),
            ),

            // Side Home Navbar
            Positioned(
              right: 0,
              top: screenHeight * 0.5 - 50.h,
              child: const CustomHomeNavBar(),
            ),
          ],
        ),
      ),
    );
  }

  // ── DESKTOP ────────────────────────────────────────────────────────────────
  Widget _buildDesktopLayout(BuildContext context,
      FeedbackEvaluationViewModel viewModel, double screenWidth) {
    final screenHeight = MediaQuery.of(context).size.height;
    final double containerWidth =
    screenWidth > 1200 ? 700.0 : screenWidth * 0.72;

    return Scaffold(
      body: Stack(
        children: [
          // Background image
          Positioned.fill(
            child: Opacity(
              opacity: 0.1,
              child: Image.asset(
                'assets/images/web_background.png',
                fit: BoxFit.cover,
              ),
            ),
          ),

          // Desktop AppBar
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: DesktopAppBar(
              screenWidth: screenWidth,
              screenHeight: screenHeight,
              title: 'okr'.tr,
              subtitle: 'feedback'.tr,
            ),
          ),

          // Centered white scrollable card
          Positioned(
            top: 110,
            left: 0,
            right: 0,
            bottom: 80,
            child: Center(
              child: Container(
                width: containerWidth,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 20,
                      spreadRadius: 4,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(32),
                  child: _buildContent(viewModel, screenWidth),
                ),
              ),
            ),
          ),

          // Sticky continue button (bottom center)
          Positioned(
            left: 0,
            right: 0,
            bottom: 20,
            child: Center(
              child: SizedBox(
                width: containerWidth * 0.45,
                child: _buildContinueButton(screenWidth),
              ),
            ),
          ),

          // Back SVG (bottom left) — same as other desktop screens
          Positioned(
            bottom: 20,
            left: 0,
            child: GestureDetector(
              onTap: () => Get.back(),
              child: CustomSvg(
                assetPath: 'assets/images/left.svg',
                semanticsLabel: '',
              ),
            ),
          ),

          // Home NavBar (bottom center-right)
          Positioned(
            bottom: 20,
            left: 0,
            right: -30,
            child: Center(child: const CustomHomeNavBar()),
          ),
        ],
      ),
    );
  }

  // ── SHARED CONTENT ─────────────────────────────────────────────────────────
  Widget _buildContent(
      FeedbackEvaluationViewModel viewModel, double screenWidth) {
    return Obx(() {
      if (viewModel.isLoadingData) {
        return Center(
          child: Padding(
            padding: EdgeInsets.only(top: 100.h),
            child: const CircularProgressIndicator(),
          ),
        );
      }

      if (!viewModel.hasData || viewModel.evaluationResult == null) {
        return Center(
          child: Padding(
            padding: EdgeInsets.only(top: 100.h),
            child: Text(
              'no_feedback_data_available'.tr,
              style: TextStyle(fontSize: _fs(screenWidth, 14)),
            ),
          ),
        );
      }

      final feedback = viewModel.evaluationResult!;

      return Column(
        children: [
          CustomScoreCard(title: '', score: feedback.overallScore),
          SizedBox(height: screenWidth >= 768 ? 8 : 4.h),
          Padding(
            padding: EdgeInsets.all(screenWidth >= 768 ? 8 : 8.w),
            child: _buildScoreBreakdown(feedback, screenWidth),
          ),
          SizedBox(height: screenWidth >= 768 ? 8 : 4.h),
          Padding(
            padding: EdgeInsets.all(screenWidth >= 768 ? 12 : 12.w),
            child: _buildFeedbackCard(feedback, screenWidth),
          ),
          SizedBox(height: screenWidth >= 768 ? 20 : 20.h),
        ],
      );
    });
  }

  // ── CONTINUE BUTTON ────────────────────────────────────────────────────────
  Widget _buildContinueButton(double screenWidth) {
    return Obx(() {
      final viewModel = Get.find<FeedbackEvaluationViewModel>();
      final isEnabled = viewModel.hasData && !viewModel.isLoadingData;

      return CustomButton2(
        text: 'continue'.tr,
        onPressed: isEnabled ? () => _navigateBasedOnGameMode() : null,
      );
    });
  }

  // ── SCORE BREAKDOWN ────────────────────────────────────────────────────────
  Widget _buildScoreBreakdown(
      FeedbackEvaluationModel feedback, double screenWidth) {
    final breakdown = feedback.breakdown;
    final normalizedScore = feedback.normalizedScore;

    final scores = [
      {
        'score': '${breakdown.strategyAlignment.score}/40',
        'label': 'strategy_alignment'.tr,
      },
      {
        'score': '${breakdown.objectiveAlignment.score}/40',
        'label': 'objective_alignment'.tr,
      },
      {
        'score': '${breakdown.keyResultQuality.score}/40',
        'label': 'key_result_quality'.tr,
      },
    ];

    return Column(
      children: [
        Text(
          'score'.tr.replaceFirst('${0}', normalizedScore.toString()),
          style: TextStyle(
            fontFamily: 'GothamBold',
            // ✅ Adaptive: 16 logical px on desktop, .sp on mobile
            fontSize: _fs(screenWidth, 18, tablet: 17, desktop: 16),
            fontWeight: FontWeight.bold,
            color: const Color(0xFF1E3A8A),
          ),
        ),
        SizedBox(height: screenWidth >= 768 ? 12 : 12.h),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: scores.map((item) {
            return Flexible(
              child: Container(
                margin: EdgeInsets.symmetric(
                    horizontal: screenWidth >= 768 ? 4 : 4.w),
                padding: EdgeInsets.symmetric(
                  vertical: screenWidth >= 768 ? 14 : 16.h,
                  horizontal: screenWidth >= 768 ? 4 : 4.w,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFFF5F5F5),
                  borderRadius: BorderRadius.circular(
                      screenWidth >= 768 ? 14 : 16.r),
                  border: Border.all(color: const Color(0xFFE0E0E0), width: 1),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      item['score']!,
                      style: TextStyle(
                        fontFamily: 'GothamBold',
                        // ✅ Adaptive score number
                        fontSize: _fs(screenWidth, 18, tablet: 16, desktop: 15),
                        fontWeight: FontWeight.bold,
                        color: const Color(0xFF1E3A8A),
                      ),
                    ),
                    SizedBox(height: screenWidth >= 768 ? 5 : 6.h),
                    Text(
                      item['label']!,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'Gotham',
                        // ✅ Adaptive label
                        fontSize: _fs(screenWidth, 9, tablet: 9, desktop: 10),
                        color: Colors.black87,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  // ── FEEDBACK CARD ──────────────────────────────────────────────────────────
  Widget _buildFeedbackCard(
      FeedbackEvaluationModel feedback, double screenWidth) {
    final breakdown = feedback.breakdown;

    return Container(
      padding: EdgeInsets.all(screenWidth >= 768 ? 20 : 20.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
        BorderRadius.circular(screenWidth >= 768 ? 16 : 20.r),
        border: Border.all(color: const Color(0xFFCC4A2E), width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(screenWidth >= 768 ? 7 : 8.w),
                decoration: const BoxDecoration(
                  color: Color(0xFFCC4A2E),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.thumb_up,
                  color: Colors.white,
                  // ✅ Adaptive icon
                  size: _fs(screenWidth, 20, tablet: 18, desktop: 18),
                ),
              ),
              SizedBox(width: screenWidth >= 768 ? 8 : 8.w),
              Text(
                'okr_evaluation_feedback'.tr,
                style: TextStyle(
                  fontFamily: 'GothamBold',
                  // ✅ Adaptive header
                  fontSize: _fs(screenWidth, 16, tablet: 15, desktop: 14),
                  fontWeight: FontWeight.bold,
                  color: const Color(0xFF1E3A8A),
                ),
              ),
            ],
          ),

          SizedBox(height: screenWidth >= 768 ? 16 : 20.h),

          // Overall feedback text
          Text(
            feedback.feedback,
            style: TextStyle(
              fontFamily: 'Gotham',
              // ✅ Adaptive body text
              fontSize: _fs(screenWidth, 14, tablet: 13, desktop: 13),
              color: Colors.black54,
              height: 1.5,
            ),
          ),

          SizedBox(height: screenWidth >= 768 ? 16 : 20.h),

          _buildFeedbackItem(
            screenWidth: screenWidth,
            title: 'strategy_alignment'.tr,
            rating: breakdown.strategyAlignment.title,
            ratingColor: _getRatingColor(breakdown.strategyAlignment.title),
            description: breakdown.strategyAlignment.suggestion,
          ),

          SizedBox(height: screenWidth >= 768 ? 14 : 16.h),

          _buildFeedbackItem(
            screenWidth: screenWidth,
            title: 'objective_alignment'.tr,
            rating: breakdown.objectiveAlignment.title,
            ratingColor: _getRatingColor(breakdown.objectiveAlignment.title),
            description: breakdown.objectiveAlignment.suggestion,
          ),

          SizedBox(height: screenWidth >= 768 ? 14 : 16.h),

          _buildFeedbackItem(
            screenWidth: screenWidth,
            title: 'key_result_quality'.tr,
            rating: breakdown.keyResultQuality.title,
            ratingColor: _getRatingColor(breakdown.keyResultQuality.title),
            description: breakdown.keyResultQuality.suggestion,
          ),
        ],
      ),
    );
  }

  // ── FEEDBACK ITEM ──────────────────────────────────────────────────────────
  Widget _buildFeedbackItem({
    required double screenWidth,
    required String title,
    required String rating,
    required Color ratingColor,
    required String description,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              title,
              style: TextStyle(
                fontFamily: 'GothamBold',
                // ✅ Adaptive
                fontSize: _fs(screenWidth, 16, tablet: 14, desktop: 14),
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            Text(
              rating,
              style: TextStyle(
                fontFamily: 'GothamBold',
                fontSize: _fs(screenWidth, 14, tablet: 13, desktop: 13),
                fontWeight: FontWeight.bold,
                color: ratingColor,
              ),
            ),
          ],
        ),
        SizedBox(height: screenWidth >= 768 ? 6 : 8.h),
        Text(
          description,
          style: TextStyle(
            fontFamily: 'Gotham',
            fontSize: _fs(screenWidth, 14, tablet: 13, desktop: 13),
            color: Colors.black54,
            height: 1.5,
          ),
        ),
      ],
    );
  }

  // ── HELPERS ────────────────────────────────────────────────────────────────
  Color _getRatingColor(String rating) {
    switch (rating.toLowerCase()) {
      case 'perfect':
        return const Color(0xFFCC4A2E);
      case 'excellent':
        return const Color(0xFF4CAF50);
      case 'good':
        return const Color(0xFF2196F3);
      case 'average':
        return const Color(0xFFFF9800);
      default:
        return const Color(0xFF9E9E9E);
    }
  }

  void _markLevelComplete() async {
    try {
      final savedMode = await SharedPrefs.getGameMode();
      if (savedMode == 'campaign') {
        final currentLevelStr =
            await SharedPrefs.getString('current_campaign_level') ?? '1';
        final currentLevel = int.tryParse(currentLevelStr) ?? 1;
        await CampaignProgressService.completeLevel(currentLevel);

        Get.snackbar(
          'Level Completed!'.tr,
          'Organization ${currentLevel == 1 ? 'A' : currentLevel == 2 ? 'B' : 'C'} completed!'
              .tr,
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.green,
          colorText: Colors.white,
        );
      }
    } catch (e) {
      debugPrint('❌ Error marking level complete: $e');
    }
  }

  void _navigateBasedOnGameMode() async {
    try {
      final savedMode = await SharedPrefs.getGameMode();
      if (savedMode == 'campaign') _markLevelComplete();

      switch (savedMode) {
        case 'solo':
        case 'challenge':
          Get.toNamed(AppRoutes.suggestionInitiativeScreen);
          break;
        case 'campaign':
          Get.offAllNamed(AppRoutes.campaignModeScreen);
          break;
        default:
          Get.toNamed(AppRoutes.suggestionInitiativeScreen);
          break;
      }
    } catch (e) {
      debugPrint('❌ Error in navigation: $e');
      Get.toNamed(AppRoutes.suggestionInitiativeScreen);
    }
  }
}





// // lib/presentation/views/feedback/feedback_screen.dart
// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:game_app/presentation/routes/app_routes.dart';
// import 'package:get/get.dart';
// import 'package:game_app/generated/models/responses/key_results/key_results_response.dart' as key_result_models;
// import '../../generated/models/requests/campaign_mode/feedback_evaluation_model.dart';
// import '../../services/shared_preference.dart';
// import '../../view_model/campaign_mode/feedback_evaluation_view_model.dart';
// import '../widgets/campaign_progress_service.dart';
// import '../widgets/custom_button2.dart';
// import '../widgets/custom_home_navbar.dart';
// import '../widgets/game_complete_widgets/custom_score_card.dart';
// import '../widgets/screens_unique_parts/custom_background.dart';
// import '../widgets/screens_unique_parts/custom_header.dart';
//
// class FeedbackScreen extends StatelessWidget {
//   final List<key_result_models.KeyResult> selectedKeyResults;
//
//   const FeedbackScreen({super.key, required this.selectedKeyResults});
//
//   @override
//   Widget build(BuildContext context) {
//     final viewModel = Get.put(FeedbackEvaluationViewModel());
//
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       viewModel.evaluateSelectedKeyResults(selectedKeyResults);
//     });
//
//     final screenHeight = MediaQuery.of(context).size.height;
//
//     return Scaffold(
//       body: CustomBackground(
//         child: Stack(
//           children: [
//             // 1️⃣ Scrollable content
//             Padding(
//               padding: EdgeInsets.only(bottom: 80.h), // leave space for button
//               child: SingleChildScrollView(
//                 padding: EdgeInsets.symmetric(vertical: 14.w, horizontal: 16.w),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     CustomHeader(
//                       title: 'okr'.tr,
//                       highlightedText: "feedback".tr,
//                       onBackTap: () => Get.back(),
//                     ),
//                     SizedBox(height: 20.h),
//
//                     // FIXED: Better Obx usage with proper reactive variables
//                     _buildContent(viewModel),
//                   ],
//                 ),
//               ),
//             ),
//
//             // 2️⃣ Sticky bottom button
//             Positioned(
//               left: 16.w,
//               right: 16.w,
//               bottom: 16.h,
//               child: _buildContinueButton(),
//             ),
//
//             // 3️⃣ Side Home Navbar
//             Positioned(
//               right: 0,
//               top: screenHeight * 0.5 - 50.h, // adjust to vertical center
//               child: const CustomHomeNavBar(),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   // FIXED: Extract content building to separate method with proper Obx usage
//   Widget _buildContent(FeedbackEvaluationViewModel viewModel) {
//     return Obx(() {
//       // Make sure these are observable variables in your ViewModel
//       if (viewModel.isLoadingData) {
//         return Center(
//           child: Padding(
//             padding: EdgeInsets.only(top: 100.h),
//             child: CircularProgressIndicator(),
//           ),
//         );
//       }
//
//       if (!viewModel.hasData) {
//         return Center(
//           child: Padding(
//             padding: EdgeInsets.only(top: 100.h),
//             child: Text('no_feedback_data_available'.tr),
//           ),
//         );
//       }
//
//       final feedback = viewModel.evaluationResult;
//       if (feedback == null) {
//         return Center(
//           child: Padding(
//             padding: EdgeInsets.only(top: 100.h),
//             child: Text('no_feedback_data_available'.tr),
//           ),
//         );
//       }
//
//       return Column(
//         children: [
//           CustomScoreCard(
//             title: "",
//             score: feedback.overallScore,
//           ),
//           SizedBox(height: 4.h),
//           Padding(
//             padding: EdgeInsets.all(8.w),
//             child: _buildScoreBreakdown(feedback),
//           ),
//           SizedBox(height: 4.h),
//           Padding(
//             padding: EdgeInsets.all(12.w),
//             child: _buildFeedbackCard(feedback),
//           ),
//           SizedBox(height: 20.h),
//         ],
//       );
//     });
//   }
//
//   // FIXED: Extract button to separate widget
//   Widget _buildContinueButton() {
//     return Obx(() {
//       final viewModel = Get.find<FeedbackEvaluationViewModel>();
//       final isEnabled = viewModel.hasData && !viewModel.isLoadingData;
//
//       return CustomButton2(
//         height: 75,
//         width: 100.h,
//         text: 'continue'.tr,
//         onPressed: isEnabled ? () => _navigateBasedOnGameMode() : null,
//       );
//     });
//   }
//
//   // In your FeedbackScreen, add this when level is completed
//   void _markLevelComplete() async {
//     try {
//       // Check if we're in campaign mode
//       final savedMode = await SharedPrefs.getGameMode();
//       if (savedMode == 'campaign') {
//         // Get current level from storage or default to 1
//         final currentLevelStr = await SharedPrefs.getString('current_campaign_level') ?? '1';
//         final currentLevel = int.tryParse(currentLevelStr) ?? 1;
//
//         // Mark level as completed
//         await CampaignProgressService.completeLevel(currentLevel);
//
//         print('✅ Campaign Level $currentLevel marked as completed!');
//
//         // Show completion message
//         Get.snackbar(
//           "Level Completed!".tr,
//           "Organization ${currentLevel == 1 ? 'A' : currentLevel == 2 ? 'B' : 'C'} completed!".tr,
//           snackPosition: SnackPosition.BOTTOM,
//           backgroundColor: Colors.green,
//           colorText: Colors.white,
//         );
//       }
//     } catch (e) {
//       print('❌ Error marking level complete: $e');
//     }
//   }
//
//   // Call this method when user completes the feedback screen
//   // Add this to your Continue button logic or when evaluation is successful
//   void _navigateBasedOnGameMode() async {
//     try {
//       final savedMode = await SharedPrefs.getGameMode();
//
//       if (savedMode == 'campaign') {
//         // Mark level as complete before navigating
//         _markLevelComplete();
//       }
//
//       // Rest of your navigation logic...
//       switch (savedMode) {
//         case 'solo':
//         case 'challenge':
//           Get.toNamed(AppRoutes.suggestionInitiativeScreen);
//           break;
//         case 'campaign':
//         // Go back to campaign screen to show updated progress
//           Get.offAllNamed(AppRoutes.campaignModeScreen);
//           break;
//         default:
//           Get.toNamed(AppRoutes.suggestionInitiativeScreen);
//           break;
//       }
//     } catch (e) {
//       print('❌ Error in navigation: $e');
//       Get.toNamed(AppRoutes.suggestionInitiativeScreen);
//     }
//   }
//
//   Widget _buildScoreBreakdown(FeedbackEvaluationModel feedback) {
//     final breakdown = feedback.breakdown;
//
//     // Use normalized score for display
//     final normalizedScore = feedback.normalizedScore;
//
//     final scores = [
//       {'score': '${breakdown.strategyAlignment.score}/40', 'label': 'strategy_alignment'.tr},
//       {'score': '${breakdown.objectiveAlignment.score}/40', 'label': 'objective_alignment'.tr},
//       {'score': '${breakdown.keyResultQuality.score}/40', 'label': 'key_result_quality'.tr},
//     ];
//
//     return Column(
//       children: [
//         // Overall normalized score
//         Text(
//           'score'.tr.replaceFirst('${0}', normalizedScore.toString()),
//           style: TextStyle(
//             fontFamily: 'GothamBold',
//             fontSize: 18.sp,
//             fontWeight: FontWeight.bold,
//             color: const Color(0xFF1E3A8A),
//           ),
//         ),
//         SizedBox(height: 12.h),
//
//         // FIXED: Breakdown scores - Use Wrap or Flexible to prevent overflow
//         Row(
//           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//           children: scores.map((item) {
//             return Flexible( // FIX: Use Flexible to allow wrapping
//               child: Container(
//                 margin: EdgeInsets.symmetric(horizontal: 4.w), // Reduced margin
//                 padding: EdgeInsets.symmetric(vertical: 16.h, horizontal: 4.w), // Reduced padding
//                 decoration: BoxDecoration(
//                   color: const Color(0xFFF5F5F5),
//                   borderRadius: BorderRadius.circular(16.r),
//                   border: Border.all(
//                     color: const Color(0xFFE0E0E0),
//                     width: 1,
//                   ),
//                 ),
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Text(
//                       item['score']!,
//                       style: TextStyle(
//                         fontFamily: 'GothamBold',
//                         fontSize: 18.sp, // Slightly smaller font
//                         fontWeight: FontWeight.bold,
//                         color: const Color(0xFF1E3A8A),
//                       ),
//                     ),
//                     SizedBox(height: 6.h),
//                     Text(
//                       item['label']!,
//                       textAlign: TextAlign.center,
//                       style: TextStyle(
//                         fontFamily: 'Gotham',
//                         fontSize: 9.sp, // Smaller font
//                         color: Colors.black87,
//                       ),
//                       maxLines: 2, // Allow text to wrap
//                       overflow: TextOverflow.ellipsis,
//                     ),
//                   ],
//                 ),
//               ),
//             );
//           }).toList(),
//         ),
//       ],
//     );
//   }
//
//   Widget _buildFeedbackCard(FeedbackEvaluationModel feedback) {
//     final breakdown = feedback.breakdown;
//
//     return Container(
//       padding: EdgeInsets.all(20.w),
//       decoration: BoxDecoration(
//         color: Colors.white,
//         borderRadius: BorderRadius.circular(20.r),
//         border: Border.all(
//           color: const Color(0xFFCC4A2E),
//           width: 2,
//         ),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           // Header
//           Row(
//             children: [
//               Container(
//                 padding: EdgeInsets.all(8.w),
//                 decoration: const BoxDecoration(
//                   color: Color(0xFFCC4A2E),
//                   shape: BoxShape.circle,
//                 ),
//                 child: Icon(
//                   Icons.thumb_up,
//                   color: Colors.white,
//                   size: 20.sp,
//                 ),
//               ),
//               SizedBox(width: 8.w),
//               Text(
//                 'okr_evaluation_feedback'.tr,
//                 style: TextStyle(
//                   fontFamily: 'GothamBold',
//                   fontSize: 16.sp,
//                   fontWeight: FontWeight.bold,
//                   color: const Color(0xFF1E3A8A),
//                 ),
//               ),
//             ],
//           ),
//
//           SizedBox(height: 20.h),
//
//           // Overall Feedback
//           Text(
//             feedback.feedback,
//             style: TextStyle(
//               fontFamily: 'Gotham',
//               fontSize: 14.sp,
//               color: Colors.black54,
//               height: 1.5,
//             ),
//           ),
//
//           SizedBox(height: 20.h),
//
//           // Strategy Alignment
//           _buildFeedbackItem(
//             title: 'strategy_alignment'.tr,
//             rating: breakdown.strategyAlignment.title,
//             ratingColor: _getRatingColor(breakdown.strategyAlignment.title),
//             description: breakdown.strategyAlignment.suggestion,
//           ),
//
//           SizedBox(height: 16.h),
//
//           // Objective Alignment
//           _buildFeedbackItem(
//             title: 'objective_alignment'.tr,
//             rating: breakdown.objectiveAlignment.title,
//             ratingColor: _getRatingColor(breakdown.objectiveAlignment.title),
//             description: breakdown.objectiveAlignment.suggestion,
//           ),
//
//           SizedBox(height: 16.h),
//
//           // Key Result Quality
//           _buildFeedbackItem(
//             title: 'key_result_quality'.tr,
//             rating: breakdown.keyResultQuality.title,
//             ratingColor: _getRatingColor(breakdown.keyResultQuality.title),
//             description: breakdown.keyResultQuality.suggestion,
//           ),
//         ],
//       ),
//     );
//   }
//
//   Color _getRatingColor(String rating) {
//     switch (rating.toLowerCase()) {
//       case 'perfect':
//         return Color(0xFFCC4A2E);
//       case 'excellent':
//         return Color(0xFF4CAF50);
//       case 'good':
//         return Color(0xFF2196F3);
//       case 'average':
//         return Color(0xFFFF9800);
//       default:
//         return Color(0xFF9E9E9E);
//     }
//   }
//
//   Widget _buildFeedbackItem({
//     required String title,
//     required String rating,
//     required Color ratingColor,
//     required String description,
//   }) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Row(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           children: [
//             Text(
//               title,
//               style: TextStyle(
//                 fontFamily: 'GothamBold',
//                 fontSize: 16.sp,
//                 fontWeight: FontWeight.bold,
//                 color: Colors.black87,
//               ),
//             ),
//             Text(
//               rating,
//               style: TextStyle(
//                 fontFamily: 'GothamBold',
//                 fontSize: 14.sp,
//                 fontWeight: FontWeight.bold,
//                 color: ratingColor,
//               ),
//             ),
//           ],
//         ),
//         SizedBox(height: 8.h),
//         Text(
//           description,
//           style: TextStyle(
//             fontFamily: 'Gotham',
//             fontSize: 14.sp,
//             color: Colors.black54,
//             height: 1.5,
//           ),
//         ),
//       ],
//     );
//   }
//
//   Widget _buildCertificationButton() {
//     return GestureDetector(
//       onTap: () {
//         // Navigate to certification test
//       },
//       child: Container(
//         width: double.infinity,
//         padding: EdgeInsets.symmetric(vertical: 16.h),
//         decoration: BoxDecoration(
//           color: const Color(0xFFCC4A2E),
//           borderRadius: BorderRadius.circular(50.r),
//           boxShadow: [
//             BoxShadow(
//               color: const Color(0xFFCC4A2E).withOpacity(0.3),
//               blurRadius: 10,
//               offset: const Offset(0, 5),
//             ),
//           ],
//         ),
//         child: Row(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Icon(
//               Icons.play_arrow,
//               color: Colors.white,
//               size: 24.sp,
//             ),
//             SizedBox(width: 8.w),
//             Text(
//               'start_certification_test'.tr,
//               style: TextStyle(
//                 fontFamily: 'GothamBold',
//                 fontSize: 16.sp,
//                 fontWeight: FontWeight.bold,
//                 color: Colors.white,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }