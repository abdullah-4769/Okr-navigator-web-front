import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../controllers/journey_controller.dart';
import '../../../controllers/strategy_selection_controller.dart';
import '../../../core/app_colors.dart';
import '../../../core/app_dimensions.dart';
import '../../../services/shared_preference.dart';
import '../../routes/app_routes.dart';
import '../../widgets/Website/desktop_appbar.dart';
import '../../widgets/custom_button2.dart';
import '../../widgets/custom_cards_pagebuilder.dart';
import '../../widgets/custom_home_navbar.dart';
import '../../widgets/custom_journey_map.dart';
import '../../widgets/custom_svg.dart';
import '../../widgets/screens_unique_parts/custom_background.dart';
import '../../widgets/screens_unique_parts/custom_header.dart';

// ─── Adaptive helpers ────────────────────────────────────────────────────────
double _fs(double sw, double mobile, {double? tablet, double? desktop}) {
  if (sw >= 1024) return desktop ?? tablet ?? mobile;
  if (sw >= 768)  return tablet  ?? mobile;
  return mobile.sp;
}
double _d(double sw, double v)  => sw >= 768 ? v : v.w;
double _dh(double sw, double v) => sw >= 768 ? v : v.h;

class StrategySelectionScreen extends StatelessWidget {
  StrategySelectionScreen({super.key});

  // ✅ Use find — these are registered by the binding before navigation
  final JourneyController         journeyController = Get.find<JourneyController>();
  final StrategySelectionController controller       = Get.find<StrategySelectionController>();

  @override
  Widget build(BuildContext context) {
    // Reset to back card after frame (same as original)
    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.resetToBackCard();
    });

    final args             = Get.arguments as Map<String, dynamic>?;
    final selectedRole     = args?['selectedRole']     as Map<String, dynamic>?;
    final selectedIndustry = args?['selectedIndustry'] as Map<String, dynamic>?;

    final sw = MediaQuery.of(context).size.width;
    final sh = MediaQuery.of(context).size.height;

    if (sw >= 768) return _buildDesktopLayout(context, sw, sh, selectedRole, selectedIndustry);
    return _buildMobileLayout(context, sw, sh, selectedRole, selectedIndustry);
  }

  // ==========================================================================
  // MOBILE LAYOUT — unchanged from original
  // ==========================================================================
  Widget _buildMobileLayout(
      BuildContext context,
      double sw,
      double sh,
      Map<String, dynamic>? selectedRole,
      Map<String, dynamic>? selectedIndustry,
      ) {
    return Scaffold(
      body: CustomBackground(
        child: SafeArea(
          child: Stack(
            children: [
              Positioned.fill(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: Padding(
                    padding: EdgeInsets.only(bottom: AppDimensions.d20.h),
                    child: _buildContent(
                      context, sw, sh, selectedRole, selectedIndustry,
                    ),
                  ),
                ),
              ),
              Positioned(
                right: sw * -0.07,
                top:   sh * 0.50,
                child: const CustomHomeNavBar(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ==========================================================================
  // DESKTOP LAYOUT — matches established web pattern exactly
  // ==========================================================================
  Widget _buildDesktopLayout(
      BuildContext context,
      double sw,
      double sh,
      Map<String, dynamic>? selectedRole,
      Map<String, dynamic>? selectedIndustry,
      ) {
    final double containerWidth = sw > 1200 ? 720.0 : sw * 0.72;

    return Scaffold(
      body: Stack(
        children: [
          // Background image 10% opacity
          Positioned.fill(
            child: Opacity(
              opacity: 0.1,
              child: Image.asset(
                'assets/images/web_background.png',
                fit: BoxFit.cover,
              ),
            ),
          ),

          // DesktopAppBar pinned at top
          Positioned(
            top: 0, left: 0, right: 0,
            child: DesktopAppBar(
              screenWidth:  sw,
              screenHeight: sh,
              title:    'strategy'.tr,
              subtitle: 'selection'.tr,
            ),
          ),

          // White centered card
          Positioned(
            top: 110, left: 0, right: 0, bottom: 80,
            child: Center(
              child: Container(
                width: containerWidth,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 20,
                      spreadRadius: 4,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(36),
                  child: _buildContent(
                    context, sw, sh, selectedRole, selectedIndustry,
                  ),
                ),
              ),
            ),
          ),

          // Back SVG bottom-left
          Positioned(
            bottom: 20, left: 0,
            child: GestureDetector(
              onTap: () {
                final gameMode = SharedPrefs.getGameMode();
                if (gameMode == 'campaign') {
                  Get.offAllNamed(AppRoutes.missionScreen);
                } else {
                  Get.offAllNamed(AppRoutes.chooseIndustry);
                }
              },
              child: CustomSvg(
                assetPath:      'assets/images/left.svg',
                semanticsLabel: '',
              ),
            ),
          ),

          // Bottom nav bar
          Positioned(
            bottom: 20, left: 0, right: -30,
            child: Center(child: const CustomHomeNavBar()),
          ),
        ],
      ),
    );
  }

  // ==========================================================================
  // SHARED CONTENT — same for mobile and desktop
  // ==========================================================================
  Widget _buildContent(
      BuildContext context,
      double sw,
      double sh,
      Map<String, dynamic>? selectedRole,
      Map<String, dynamic>? selectedIndustry,
      ) {
    return Column(
      children: [
        SizedBox(height: sw >= 768 ? 20.0 : sh * 0.03),

        // Header
        CustomHeader(
          title:           'strategy'.tr,
          highlightedText: 'selection'.tr,
          onBackTap: () {
            final gameMode = SharedPrefs.getGameMode();
            if (gameMode == 'campaign') {
              Get.offAllNamed(AppRoutes.missionScreen);
            } else {
              Get.offAllNamed(AppRoutes.chooseIndustry);
            }
          },
        ),

        SizedBox(height: sw >= 768 ? 16.0 : sh * 0.01),

        // Draw strategy text
        Padding(
          padding: EdgeInsets.symmetric(horizontal: _d(sw, sw * 0.06)),
          child: Column(
            children: [
              Text(
                'draw_strategy'.tr,
                style: TextStyle(
                  fontFamily: 'GothamBold',
                  fontSize:   _fs(sw, sw * 0.055, desktop: 22),
                  color:      AppColors.primaryRed,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: sw >= 768 ? 10.0 : sh * 0.01),
              Text(
                'draw_strategy_subtitle'.tr,
                style: TextStyle(
                  fontSize:   _fs(sw, sw * 0.037, desktop: 14),
                  color:      AppColors.textSecondary,
                  fontFamily: 'Gotham',
                  height: 1.4,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),

        SizedBox(height: sw >= 768 ? 24.0 : sh * 0.03),

        // Card pager — key widget unchanged
        CustomCardPagerBuilder(controller: controller),

        SizedBox(height: sw >= 768 ? 24.0 : sh * 0.03),

        // Begin Mission button
        Obx(() => Padding(
          padding: EdgeInsets.symmetric(horizontal: _d(sw, sw * 0.12)),
          child: CustomButton2(
            text:      'begin_mission'.tr,
            onPressed: controller.canBeginMission
                ? () {
              journeyController.completeStep(0);
              controller.beginMission(selectedRole, selectedIndustry);
            }
                : null,
          ),
        )),

        SizedBox(height: sw >= 768 ? 24.0 : sh * 0.03),

        // Journey map
        Obx(() => CustomJourneyMap(
          progress:       journeyController.progress.value,
          steps:          journeyController.steps,
          completedSteps: journeyController.completedSteps,
          onToggle:       journeyController.toggleJourneyDetails,
          showDetails:    journeyController.showDetails.value,
        )),

        SizedBox(height: sw >= 768 ? 24.0 : sh * 0.03),
      ],
    );
  }
}







// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:get/get.dart';
//
// import '../../../controllers/journey_controller.dart';
// import '../../../controllers/strategy_selection_controller.dart';
// import '../../../core/app_colors.dart';
// import '../../../core/app_dimensions.dart';
// import '../../../services/shared_preference.dart';
// import '../../routes/app_routes.dart';
// import '../../widgets/Website/desktop_appbar.dart';
// import '../../widgets/custom_button2.dart';
// import '../../widgets/custom_cards_pagebuilder.dart';
// import '../../widgets/custom_home_navbar.dart';
// import '../../widgets/custom_journey_map.dart';
// import '../../widgets/custom_svg.dart';
// import '../../widgets/screens_unique_parts/custom_background.dart';
// import '../../widgets/screens_unique_parts/custom_header.dart';
//
// class StrategySelectionScreen extends StatelessWidget {
//   StrategySelectionScreen({super.key});
//
//   final journeyController = Get.find<JourneyController>();
//   final controller = Get.find<StrategySelectionController>();
//
//   @override
//   Widget build(BuildContext context) {
//
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       controller.resetToBackCard();
//     });
//
//     // ✅ Get arguments from GetX
//     final args = Get.arguments as Map<String, dynamic>?;
//     final selectedRole = args?['selectedRole'] as Map<String, dynamic>?;
//     final selectedIndustry = args?['selectedIndustry'] as Map<String, dynamic>?;
//
//     return LayoutBuilder(builder: (context, constraints) {
//       double screenWidth = constraints.maxWidth;
//       double screenHeight = constraints.maxHeight;
//
//       // Device detection
//       bool isMobile = screenWidth < 768;
//       bool isTablet = screenWidth >= 768 && screenWidth < 1024;
//       bool isDesktop = screenWidth >= 1024;
//
//       // Responsive font helpers
//       double headerFont(double mobile, double tablet, double desktop) =>
//           isMobile ? mobile : isTablet ? tablet : desktop;
//       double bodyFont(double mobile, double tablet, double desktop) =>
//           isMobile ? mobile : isTablet ? tablet : desktop;
//       double buttonFont(double mobile, double tablet, double desktop) =>
//           isMobile ? mobile : isTablet ? tablet : desktop;
//
//       double containerPadding() => isMobile ? 20 : isTablet ? 30 : 40;
//       double containerWidth() =>
//           isMobile
//               ? screenWidth * 0.9
//               : isTablet
//               ? screenWidth * 0.7
//               : 600;
//
//       if (isMobile) {
//         return _buildMobileLayout(
//             context,
//             headerFont,
//             bodyFont,
//             buttonFont,
//             selectedRole,
//             selectedIndustry
//         );
//       } else {
//         return _buildDesktopWebLayout(
//           context,
//           headerFont,
//           bodyFont,
//           buttonFont,
//           containerPadding(),
//           containerWidth(),
//           selectedRole,
//           selectedIndustry,
//         );
//       }
//     });
//   }
//
//   // ----------------- Mobile Layout -----------------
//   Widget _buildMobileLayout(
//       BuildContext context,
//       double Function(double, double, double) headerFont,
//       double Function(double, double, double) bodyFont,
//       double Function(double, double, double) buttonFont,
//       Map<String, dynamic>? selectedRole,
//       Map<String, dynamic>? selectedIndustry,
//       ) {
//     final screenWidth = MediaQuery.of(context).size.width;
//     final screenHeight = MediaQuery.of(context).size.height;
//
//     return Scaffold(
//       body: CustomBackground(
//         child: SafeArea(
//           child: Stack(
//             children: [
//               /// Scrollable Content
//               Positioned.fill(
//                 child: SingleChildScrollView(
//                   physics: const BouncingScrollPhysics(),
//                   child: Padding(
//                     padding: EdgeInsets.only(bottom: AppDimensions.d20.h),
//                     child: Column(
//                       children: [
//                         SizedBox(height: screenHeight * 0.03),
//
//                         // 🔹 Custom Header
//                         CustomHeader(
//                           title: 'select'.tr,
//                           highlightedText: 'strategy'.tr,
//                           onBackTap: () {
//                             // ✅ Navigate back based on game mode
//                             final gameMode = SharedPrefs.getGameMode();
//                             if (gameMode == 'campaign') {
//                               Get.offAllNamed(AppRoutes.missionScreen);
//                             } else {
//                               Get.offAllNamed(AppRoutes.chooseIndustry);
//                             }
//                           },
//                           showDashboardIcon: true,
//                         ),
//
//                         SizedBox(height: screenHeight * 0.01),
//
//                         // Welcome Text
//                         Padding(
//                           padding: EdgeInsets.symmetric(
//                             horizontal: screenWidth * 0.06,
//                           ),
//                           child: Column(
//                             children: [
//                               Text(
//                                 'draw_strategy'.tr,
//                                 style: TextStyle(
//                                   fontFamily: 'GothamBold',
//                                   fontSize: (screenWidth * 0.055).sp,
//                                   color: AppColors.primaryRed,
//                                   fontWeight: FontWeight.bold,
//                                 ),
//                                 textAlign: TextAlign.center,
//                               ),
//                               SizedBox(height: screenHeight * 0.01),
//                               Text(
//                                 'draw_strategy_subtitle'.tr,
//                                 style: TextStyle(
//                                   fontSize: (screenWidth * 0.037).sp,
//                                   color: AppColors.textSecondary,
//                                   fontFamily: 'Gotham',
//                                   height: 1.4,
//                                 ),
//                                 textAlign: TextAlign.center,
//                               ),
//                             ],
//                           ),
//                         ),
//
//                         SizedBox(height: screenHeight * 0.03),
//
//                         // Cards Section
//                         CustomCardPagerBuilder(controller: controller),
//
//                         SizedBox(height: screenHeight * 0.03),
//
//                         // Journey Map
//                         Obx(
//                               () => CustomJourneyMap(
//                             progress: journeyController.progress.value,
//                             steps: journeyController.steps,
//                             completedSteps: journeyController.completedSteps,
//                             onToggle: journeyController.toggleJourneyDetails,
//                             showDetails: journeyController.showDetails.value,
//                           ),
//                         ),
//
//                         SizedBox(height: screenHeight * 0.03),
//
//                         // Begin Mission Button
//                         Obx(
//                               () => Padding(
//                             padding: EdgeInsets.symmetric(
//                               horizontal: screenWidth * 0.012,
//                             ),
//                             child: CustomButton2(
//                               text: 'begin_mission'.tr,
//                               onPressed: controller.canBeginMission
//                                   ? () {
//                                 journeyController.completeStep(0); // Mark strategy step as complete
//                                 controller.beginMission(selectedRole, selectedIndustry);
//                               }
//                                   : null,
//                             ),
//                           ),
//                         ),
//
//                         SizedBox(height: screenHeight * 0.03),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
//
//               // 🔹 Floating Navbar
//               Positioned(
//                 right: screenWidth * -0.07,
//                 top: screenHeight * 0.50,
//                 child: const CustomHomeNavBar(),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   // ----------------- Desktop/Web Layout -----------------
//   Widget _buildDesktopWebLayout(
//       BuildContext context,
//       double Function(double, double, double) headerFont,
//       double Function(double, double, double) bodyFont,
//       double Function(double, double, double) buttonFont,
//       double padding,
//       double containerWidth,
//       Map<String, dynamic>? selectedRole,
//       Map<String, dynamic>? selectedIndustry,
//       ) {
//     final screenHeight = MediaQuery.of(context).size.height;
//     final screenWidth = MediaQuery.of(context).size.width;
//
//     return Scaffold(
//       body: Stack(
//         children: [
//           // Background Image with opacity
//           Positioned.fill(
//             child: Stack(
//               children: [
//                 // Background image
//                 Positioned.fill(
//                   child: Opacity(
//                     opacity: 0.1,
//                     child: Image.asset(
//                       'assets/images/web_background.png',
//                       fit: BoxFit.cover,
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//
//           Positioned(
//             top: 0,
//             left: 0,
//             right: 0,
//             child: DesktopAppBar(
//               screenWidth: screenWidth,
//               screenHeight: screenHeight,
//               title: 'select'.tr,
//               subtitle: 'strategy'.tr,
//             ),
//           ),
//
//           // Scrollable white container
//           Center(
//             child: Container(
//               width: containerWidth,
//               height: screenHeight * 0.75,
//               margin: const EdgeInsets.only(top: 120),
//               padding: EdgeInsets.all(padding),
//               decoration: BoxDecoration(
//                 color: Colors.white,
//                 borderRadius: BorderRadius.circular(20),
//                 boxShadow: [
//                   BoxShadow(
//                     color: Colors.black.withOpacity(0.1),
//                     blurRadius: 20,
//                     spreadRadius: 5,
//                     offset: const Offset(0, 10),
//                   ),
//                 ],
//               ),
//               child: SingleChildScrollView(
//                 physics: const BouncingScrollPhysics(),
//                 child: Padding(
//                   padding: EdgeInsets.only(bottom: AppDimensions.d20.h),
//                   child: Column(
//                     children: [
//                       SizedBox(height: screenHeight * 0.03),
//
//                       // Welcome Text
//                       Padding(
//                         padding: EdgeInsets.symmetric(
//                           horizontal: screenWidth * 0.06,
//                         ),
//                         child: Column(
//                           children: [
//                             Text(
//                               'draw_strategy'.tr,
//                               textAlign: TextAlign.center,
//                               style: TextStyle(
//                                 fontSize: bodyFont(14, 16, 18),
//                                 color: AppColors.primaryRed,
//                                 fontFamily: "GothamUltra",
//                               ),
//                             ),
//                             SizedBox(height: screenHeight * 0.01),
//                             Text(
//                               'draw_strategy_subtitle'.tr,
//                               textAlign: TextAlign.center,
//                               style: TextStyle(
//                                 fontSize: bodyFont(12, 14, 16),
//                                 color: AppColors.black,
//                                 fontFamily: "Gotham",
//                               ),
//                             ),
//                           ],
//                         ),
//                       ),
//
//                       SizedBox(height: screenHeight * 0.03),
//
//                       // Cards Section
//                       CustomCardPagerBuilder(controller: controller),
//
//                       SizedBox(height: screenHeight * 0.03),
//
//                       // Journey Map
//                       Obx(
//                             () => CustomJourneyMap(
//                           progress: journeyController.progress.value,
//                           steps: journeyController.steps,
//                           completedSteps: journeyController.completedSteps,
//                           onToggle: journeyController.toggleJourneyDetails,
//                           showDetails: journeyController.showDetails.value,
//                         ),
//                       ),
//
//                       SizedBox(height: screenHeight * 0.03),
//
//                       // Begin Mission Button - UPDATED with API integration
//                       Obx(
//                             () => Padding(
//                           padding: EdgeInsets.symmetric(
//                             horizontal: screenWidth * 0.003,
//                           ),
//                           child: CustomButton2(
//                             text: 'begin_mission'.tr,
//                             onPressed: controller.canBeginMission
//                                 ? () {
//                               journeyController.completeStep(0); // Mark strategy step as complete
//                               controller.beginMission(selectedRole, selectedIndustry);
//                             }
//                                 : null,
//                           ),
//                         ),
//                       ),
//
//                       SizedBox(height: screenHeight * 0.03),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//           ),
//
//           /// Back Button
//           Positioned(
//             bottom: 20,
//             left: 0,
//             child: GestureDetector(
//               onTap: () {
//                 // ✅ Navigate back based on game mode
//                 final gameMode = SharedPrefs.getGameMode();
//                 if (gameMode == 'campaign') {
//                   Get.offAllNamed(AppRoutes.missionScreen);
//                 } else {
//                   Get.offAllNamed(AppRoutes.chooseIndustry);
//                 }
//               },
//               child: CustomSvg(
//                 assetPath: 'assets/images/left.svg',
//                 semanticsLabel: '',
//               ),
//             ),
//           ),
//
//           // Home Navbar at bottom middle
//           Positioned(
//             bottom: 20,
//             left: 0,
//             right: -30,
//             child: Center(child: const CustomHomeNavBar()),
//           ),
//         ],
//       ),
//     );
//   }
// }
