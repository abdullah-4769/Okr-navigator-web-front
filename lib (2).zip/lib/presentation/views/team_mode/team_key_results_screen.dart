import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../controllers/journey_controller.dart';
import '../../../controllers/okr_constellation_controller.dart';
import '../../../controllers/team_mode_controller/team_key_results_controller.dart';
import '../../../core/app_colors.dart';
import '../../../core/app_dimensions.dart';
import '../../routes/app_routes.dart';
import '../../widgets/custom_button2.dart';
import '../../widgets/custom_home_navbar.dart';
import '../../widgets/custom_industry_container.dart';
import '../../widgets/custom_objective_container.dart';
import '../../widgets/custom_journey_map.dart';
import '../../widgets/custom_okr_constellation.dart';
import '../../widgets/screens_unique_parts/custom_background.dart';
import '../../widgets/screens_unique_parts/custom_header.dart';
import '../../widgets/team_mode_widgets/selected_custom_keyresults-Container.dart';

class TeamKeyResultsScreen extends StatelessWidget {
  TeamKeyResultsScreen({super.key});

  final TeamKeyResultsController controller = Get.put(TeamKeyResultsController());
  final OKRConstellationController constellationController = Get.put(OKRConstellationController());
  final JourneyController journeyController = Get.isRegistered<JourneyController>()
      ? Get.find<JourneyController>()
      : Get.put(JourneyController());

  String _safeTranslate(String? key, {String fallback = ''}) {
    if (key == null) return fallback;
    try {
      return key.tr;
    } catch (e) {
      return fallback;
    }
  }

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      journeyController.completeStep(1);
      journeyController.setStep(2, true);
    });

    final screenWidth = MediaQuery.of(context).size.width;

    return OrientationBuilder(
      builder: (context, orientation) => Scaffold(
        body: CustomBackground(
          child: SafeArea(
            child: Stack(
              children: [
                Positioned.fill(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    child: Padding(
                      padding: EdgeInsets.only(bottom: AppDimensions.d20.h),
                      child: Column(
                        children: [

                          /// -------- HEADER ----------
                             CustomHeader(
                              title: _safeTranslate('select'),
                              highlightedText: _safeTranslate('key_results'),
                              subtitle: '',
                              onBackTap: () => Get.offAllNamed(
                                AppRoutes.teamObjectiveSelectionScreen,
                              ),
                            ),

                          SizedBox(height: AppDimensions.d10.h),

                          /// -------- Selected Objective ---------
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 16.w),
                            child: CustomObjectiveContainer(
                              icon: Icons.rocket,
                              title: _safeTranslate('selected_objective'),
                              subtitle: _safeTranslate('launch_2_products'),
                              description: _safeTranslate('objective_description'),
                            ),
                          ),

                          SizedBox(height: AppDimensions.d16.h),

                          /// -------- Selected Count ---------
                          const CustomSelectedTeamKeyResultsContainer(),

                          SizedBox(height: AppDimensions.d14.h),

                          /// -------- Title ---------
                          Center(
                            child: Text(
                              _safeTranslate('select_key_results'),
                              style: TextStyle(
                                fontSize: AppDimensions.d22.sp,
                                fontWeight: FontWeight.bold,
                                color: AppColors.primaryRed,
                                fontFamily: 'Gotham-Bold',
                              ),
                            ),
                          ),
                          SizedBox(height: AppDimensions.d6.h),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 15.w),
                            child: Center(
                              child: Text(
                                _safeTranslate('choose_3_outcomes'),
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: AppDimensions.d15.sp,
                                  color: AppColors.textSecondary,
                                ),
                              ),
                            ),
                          ),

                          SizedBox(height: AppDimensions.d16.h),

                          /// -------- KEY RESULTS LIST ---------
                          /// -------- KEY RESULTS LIST ---------
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 12.w),
                            child: Obx(
                                  () => Column(
                                children: List.generate(
                                  controller.keyResults.length,
                                      (index) {
                                    final item = controller.keyResults[index]; // KeyResult object

                                    // Define icons based on index for variety
                                    final List<IconData> icons = [
                                      Icons.star,
                                      Icons.rocket,
                                      Icons.lightbulb,
                                      Icons.flag,
                                      Icons.trending_up,
                                      Icons.bar_chart,
                                      Icons.thumb_up,
                                      Icons.work,
                                      Icons.public,
                                      Icons.check_circle,
                                    ];

                                    final icon = icons[index % icons.length];

                                    return Padding(
                                      padding: EdgeInsets.symmetric(vertical: 8.h),
                                      child: CustomIndustryContainer(
                                        title: _safeTranslate(item.title, fallback: 'Unknown'), // ✅ Use dot notation
                                        description: _safeTranslate(item.description, fallback: 'No description'), // ✅ Use dot notation
                                        icon: icon,
                                        isSelected: controller.isSelected(index),
                                        onTap: () {
                                          controller.toggleSelection(index);
                                          if (controller.isSelected(index)) {
                                            constellationController.addIcon(icon);
                                          } else {
                                            constellationController.removeIcon(icon);
                                          }
                                        },
                                        showTag1: false, // ❌ Set to false since tag1 doesn't exist
                                        tag1Icon: null,
                                        tag1Text: '',
                                        showTag2: false, // ❌ Set to false since tag2 doesn't exist
                                        tag2Icon: null,
                                        tag2Text: '',
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ),
                          ),

                          SizedBox(height: AppDimensions.d20.h),

                          /// -------- CONSTELLATION ---------
                          const CustomOKRConstellation(),

                          SizedBox(height: AppDimensions.d20.h),

                          /// -------- JOURNEY MAP ---------
                          Obx(
                                () => Padding(
                              padding: EdgeInsets.symmetric(horizontal: 8.w),
                              child: CustomJourneyMap(
                                progress: journeyController.progress.value,
                                steps: journeyController.steps,
                                completedSteps: journeyController.completedSteps,
                                onToggle: journeyController.toggleJourneyDetails,
                                showDetails: journeyController.showDetails.value,
                              ),
                            ),
                          ),

                          SizedBox(height: AppDimensions.d24.h),

                          /// -------- BUTTON ---------
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 40.w),
                            child: Obx(
                                  () => CustomButton2(
                                text: _safeTranslate('complete_selection'),
                                onPressed: controller.selectedCount.value ==
                                    controller.requiredCount.value
                                    ? () {
                                  journeyController.completeStep(3);
                                  Get.toNamed(AppRoutes.teamSuggestionInitiativeScreen);
                                }
                                    : null,
                              ),
                            ),
                          ),

                          SizedBox(height: AppDimensions.d20.h),
                        ],
                      ),
                    ),
                  ),
                ),

                /// -------- Floating Nav --------
                Positioned(
                  right: screenWidth * -0.07000001,
                  top: MediaQuery.of(context).size.height * 0.50,
                  child: const CustomHomeNavBar(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
