// ai_analysis_screen.dart
// Web/desktop version — ALL retry, navigation, and campaign logic is
// taken EXACTLY from the working AIAnalysisShowScreen (mobile).
// Only the UI shell (Scaffold, layout) differs for desktop.

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/app_colors.dart';
import '../../../core/app_dimensions.dart';
import '../../../generated/models/requests/adaptation_analysis_model.dart';
import '../../../generated/models/responses/evaluate_initiative/evaluate_initiative_model.dart';
import '../../../services/shared_preference.dart';
import '../../../utils/snackbar_helper.dart';
import '../../../view_model/challange_view_models/adaptation_ai_analysis-viewmodel.dart';
import '../../routes/app_routes.dart';
import '../../widgets/Website/desktop_appbar.dart';
import '../../widgets/campaign_progress_service.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/custom_home_navbar.dart';
import '../../widgets/custom_svg.dart';
import '../../widgets/screens_unique_parts/custom_background.dart';
import '../../widgets/screens_unique_parts/custom_header.dart';

class AIAnalysisScreen extends StatefulWidget {
  const AIAnalysisScreen({super.key});

  @override
  State<AIAnalysisScreen> createState() => _AIAnalysisScreenState();
}

class _AIAnalysisScreenState extends State<AIAnalysisScreen> {
  // ✅ FIX: Get.put — safe even if already registered, never throws like Get.find()
  late final AdaptationAIAnalysisViewModel _viewModel;

  final int _maxRetries = 3;
  int _currentRetry = 0;
  bool _isNavigating = false;

  // ── Adaptive sizing helpers ────────────────────────────────────────────────
  static double _fs(double sw, double mobile,
      {double? tablet, double? desktop}) {
    if (sw >= 1024) return desktop ?? tablet ?? mobile - 2;
    if (sw >= 768) return tablet ?? mobile - 1;
    return mobile.sp;
  }

  static double _d(double sw, double v) => sw >= 768 ? v : v.w;
  static double _dh(double sw, double v) => sw >= 768 ? v : v.h;
  static double _dr(double sw, double v) => sw >= 768 ? v : v.r;

  String _safeTranslate(String? key, {String fallback = ''}) {
    if (key == null) return fallback;
    try { return key.tr; } catch (_) { return fallback; }
  }

  // =========================================================================
  // INIT — identical to AIAnalysisShowScreen.initState()
  // =========================================================================
  @override
  void initState() {
    super.initState();
    _viewModel = Get.put(AdaptationAIAnalysisViewModel());
    _loadRetryCount();
    _handleAnalysisBasedOnSource();
  }

  void _loadRetryCount() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (mounted) setState(() => _currentRetry = prefs.getInt('analysis_retry_count') ?? 0);
    } catch (_) { _currentRetry = 0; }
  }

  void _saveRetryCount() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('analysis_retry_count', _currentRetry);
    } catch (e) { debugPrint('❌ saveRetryCount: $e'); }
  }

  void _resetRetryCount() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('analysis_retry_count', 0);
      _currentRetry = 0;
    } catch (e) { debugPrint('❌ resetRetryCount: $e'); }
  }

  void _handleAnalysisBasedOnSource() async {
    try {
      final dynamic arguments = Get.arguments;
      final source = arguments is Map<String, dynamic> ? arguments['source'] ?? '' : '';
      final adaptationRequest = arguments is Map<String, dynamic> ? arguments['adaptationRequest'] : null;

      debugPrint('📍 Analysis Source: $source');
      debugPrint('📦 Has Adaptation Request: ${adaptationRequest != null}');

      if (source == 'challenge_adjustment' && adaptationRequest != null) {
        await _runAdaptationAnalysis(adaptationRequest);
      } else if (source == 'contextual_challenge') {
        debugPrint('🔄 Analysis from contextual challenge - skipping adaptation');
      } else {
        debugPrint('ℹ️ No adaptation analysis needed for source: $source');
      }
    } catch (e) { debugPrint('❌ _handleAnalysisBasedOnSource: $e'); }
  }

  Future<void> _runAdaptationAnalysis(dynamic adaptationRequest) async {
    try {
      if (adaptationRequest is AdaptationAnalysisRequest) {
        await _viewModel.submitAdaptationAnalysis(
          strategy: adaptationRequest.strategy,
          objective: adaptationRequest.objective,
          keyResult: adaptationRequest.keyResult,
          challenge: adaptationRequest.challenge,
          proposal: adaptationRequest.proposal ?? 'Strategic adaptations',
        );
      } else if (adaptationRequest is Map<String, dynamic>) {
        await _viewModel.submitAdaptationAnalysis(
          strategy: adaptationRequest['strategy']?.toString() ?? await _getDefaultStrategy(),
          objective: adaptationRequest['objective']?.toString() ?? await _getDefaultObjective(),
          keyResult: adaptationRequest['keyResult']?.toString() ?? 'Adapted Key Result',
          challenge: adaptationRequest['challenge']?.toString() ?? 'Market Challenge',
          proposal: adaptationRequest['proposal']?.toString() ?? 'Strategic adaptations',
        );
      } else {
        await _viewModel.submitAdaptationAnalysis(
          strategy: await _getDefaultStrategy(),
          objective: await _getDefaultObjective(),
          keyResult: 'Adapted Key Result',
          challenge: 'Market Challenge',
          proposal: 'Strategic adaptations to address market changes',
        );
      }
      debugPrint('✅ Adaptation analysis completed');
    } catch (e) { debugPrint('❌ _runAdaptationAnalysis: $e'); }
  }

  Future<String> _getDefaultStrategy() async {
    try { return (await SharedPrefs.getSelectedStrategy())?['title']?.toString() ?? 'CEO Strategy'; }
    catch (_) { return 'CEO Strategy'; }
  }

  Future<String> _getDefaultObjective() async {
    try { return (await SharedPrefs.getSelectedObjective())?['title']?.toString() ?? 'Business Growth Objective'; }
    catch (_) { return 'Business Growth Objective'; }
  }

  // =========================================================================
  // NAVIGATION — exact copy from AIAnalysisShowScreen
  // =========================================================================
  void _navigateBasedOnDecisionAndMode({
    required String decision,
    required String source,
    required bool hasData,
  }) async {
    if (_isNavigating) return;
    _isNavigating = true;

    try {
      final savedMode = await SharedPrefs.getGameMode() ?? 'solo';
      final isDecisionAccepted = _isDecisionAccepted(decision);

      debugPrint('🎯 Navigation Decision:');
      debugPrint('   - Decision: $decision (Accepted: $isDecisionAccepted)');
      debugPrint('   - Game Mode: $savedMode');
      debugPrint('   - Source: $source');
      debugPrint('   - Retry Count: $_currentRetry/$_maxRetries');

      if (!isDecisionAccepted) {
        _currentRetry++;
        _saveRetryCount();

        if (_currentRetry >= _maxRetries) {
          debugPrint('❌ Max retries reached ($_maxRetries).');
          await _showMaxRetriesDialog();
          _resetRetryCount();
          _navigateToHomeScreen();
        } else {
          debugPrint('🔄 Decision rejected. Retry $_currentRetry/$_maxRetries');
          await _showRetryDialog();
        }
        return;
      }

      _resetRetryCount();
      await _proceedWithAcceptedDecision(savedMode, source);
    } catch (e) {
      debugPrint('❌ Navigation error: $e');
      Get.snackbar('Navigation Error', 'Failed to navigate: ${e.toString()}',
          backgroundColor: Colors.red, colorText: Colors.white);
    } finally {
      _isNavigating = false;
    }
  }

  bool _isDecisionAccepted(String decision) {
    final lower = decision.toLowerCase();
    return lower.contains('accepted') ||
        lower.contains('approved') ||
        (lower.contains('review') && !lower.contains('rejected'));
  }

  // ── Dialogs — same content as mobile, adaptive width on desktop ───────────
  Future<void> _showRetryDialog() async {
    final double sw = MediaQuery.of(Get.context!).size.width;
    final double dialogWidth = sw >= 1024 ? 420.0 : sw >= 768 ? 380.0 : sw * 0.88;

    await Get.dialog(
      Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Container(
          width: dialogWidth,
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
                child: Text('initiative_rejected'.tr,
                    style: TextStyle(fontSize: _fs(sw, 16, desktop: 16), fontWeight: FontWeight.bold, color: Colors.black87, fontFamily: 'GothamBold')),
              ),
              Divider(height: 1, color: Colors.grey.withOpacity(0.2)),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 14, 20, 14),
                child: Text(
                  '${'initiative_needs_improvement'.tr}\n\n${'retry_count'.tr}: $_currentRetry/$_maxRetries\n${'suggest_improve_initiatives'.tr}',
                  style: TextStyle(fontSize: _fs(sw, 14, desktop: 13), color: Colors.black54, height: 1.5),
                ),
              ),
              Divider(height: 1, color: Colors.grey.withOpacity(0.2)),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () { Get.back(); _navigateToKeyObjectiveScreen(); },
                      child: Text('try_again'.tr,
                          style: TextStyle(fontSize: _fs(sw, 14, desktop: 13), fontWeight: FontWeight.w600, color: AppColors.primaryRed)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      barrierDismissible: false,
    );
  }

  Future<void> _showMaxRetriesDialog() async {
    final double sw = MediaQuery.of(Get.context!).size.width;
    final double dialogWidth = sw >= 1024 ? 420.0 : sw >= 768 ? 380.0 : sw * 0.88;

    await Get.dialog(
      Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Container(
          width: dialogWidth,
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
                child: Text('max_retries_reached'.tr,
                    style: TextStyle(fontSize: _fs(sw, 16, desktop: 16), fontWeight: FontWeight.bold, color: Colors.black87, fontFamily: 'GothamBold')),
              ),
              Divider(height: 1, color: Colors.grey.withOpacity(0.2)),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 14, 20, 14),
                child: Text('${'max_retries_exceeded'.tr}\n\n${'returning_to_home_screen'.tr}',
                    style: TextStyle(fontSize: _fs(sw, 14, desktop: 13), color: Colors.black54, height: 1.5)),
              ),
              Divider(height: 1, color: Colors.grey.withOpacity(0.2)),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () => Get.back(),
                      child: Text('understand'.tr,
                          style: TextStyle(fontSize: _fs(sw, 14, desktop: 13), fontWeight: FontWeight.w600, color: AppColors.primaryRed)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      barrierDismissible: false,
    );
  }

  void _navigateToKeyObjectiveScreen() {
    debugPrint('🔄 Navigating back to Key Objective Screen for retry');
    Get.offAllNamed(AppRoutes.keyObjectiveScreen,
        parameters: {'isRetry': 'true'}, arguments: Get.arguments);
  }

  void _navigateToHomeScreen() {
    debugPrint('🏠 Max retries - Navigating to home screen');
    Get.offAllNamed(AppRoutes.home);
    Future.delayed(const Duration(milliseconds: 500), () {
      SnackbarHelper.info('You have completed all 3 attempts. Please try again with a new strategy!');
    });
  }

  Future<void> _proceedWithAcceptedDecision(String savedMode, String source) async {
    debugPrint('✅ Decision accepted! Proceeding with $savedMode...');
    switch (savedMode) {
      case 'solo':
        Get.offAllNamed(AppRoutes.gameCompleteScreen);
        break;
      case 'challenge':
        await _navigateChallengeMode();
        break;
      case 'campaign':
        await _navigateCampaignMode(source);
        break;
      default:
        Get.offAllNamed(AppRoutes.gameCompleteScreen);
    }
  }

  Future<void> _navigateChallengeMode() async {
    final challengeId = await SharedPrefs.getChallengeId();
    final userId = SharedPrefs.getUserId();
    if (challengeId == null || challengeId.isEmpty || userId == null || userId.isEmpty) {
      Get.snackbar('Error', 'Challenge data not found', backgroundColor: Colors.red, colorText: Colors.white);
      return;
    }
    Get.offAllNamed(AppRoutes.gameResultScreen, arguments: {
      'challengeId': challengeId,
      'userId': userId,
      'source': 'challenge_mode',
    });
  }

  // ✅ Exact copy from AIAnalysisShowScreen — completes campaign level before navigating
  Future<void> _navigateCampaignMode(String source) async {
    debugPrint('🏆 Campaign Mode Navigation - Source: $source');

    if (source == 'contextual_challenge' || source == 'challenge_adjustment') {
      debugPrint('➡️ Campaign Mode: Completing current level...');
      final currentLevel = await _getCurrentCampaignLevel();
      debugPrint('🎯 Current campaign level: $currentLevel');

      if (currentLevel > 0 && currentLevel <= 3) {
        await CampaignProgressService.completeLevel(currentLevel);
        debugPrint('✅ Level $currentLevel marked as completed');
      }

      Get.offAllNamed(AppRoutes.campaignModeScreen);
    } else {
      debugPrint('➡️ Campaign Mode: Default navigation');
      Get.offAllNamed(AppRoutes.campaignModeScreen);
    }
  }

  Future<int> _getCurrentCampaignLevel() async {
    try {
      final levelStr = await SharedPrefs.getString('current_campaign_level');
      return int.tryParse(levelStr ?? '1') ?? 1;
    } catch (e) { return 1; }
  }

  // =========================================================================
  // ARGUMENT PARSING
  // =========================================================================
  _ParsedAnalysis _parseArguments() {
    final dynamic args = Get.arguments;
    EvaluateInitiativeModel? evaluationData;
    String source = 'initiative_analysis';

    if (args is EvaluateInitiativeModel) {
      evaluationData = args;
      source = 'initiative_analysis';
    } else if (args is Map<String, dynamic>) {
      source = args['source']?.toString() ?? 'initiative_analysis';

      final raw = args['analysisData'];
      if (raw is EvaluateInitiativeModel) {
        evaluationData = raw;
      } else if (raw is Map<String, dynamic>) {
        try { evaluationData = EvaluateInitiativeModel.fromJson(raw); } catch (_) {}
      }

      // Fallback: viewmodel has data from adaptation analysis
      if (evaluationData == null && _viewModel.evaluationData.value != null) {
        final d = _viewModel.evaluationData.value!;
        evaluationData = EvaluateInitiativeModel(
          score: d.score,
          decision: _getDecisionFromScore(d.score),
          explanation: d.feedback,
        );
        source = 'challenge_adjustment';
      }
    }

    final int score = evaluationData?.score ?? _viewModel.evaluationData.value?.score ?? 0;
    final String decision = evaluationData?.decision ?? _getDecisionFromScore(score);
    final String explanation = evaluationData?.explanation ??
        _viewModel.evaluationData.value?.feedback ?? 'No analysis available';

    return _ParsedAnalysis(
      evaluationData: evaluationData,
      source: source,
      score: score,
      decision: decision,
      explanation: explanation,
      hasData: evaluationData != null || _viewModel.evaluationData.value != null,
    );
  }

  // ── Helpers ────────────────────────────────────────────────────────────────
  String _getDecisionFromScore(int score) {
    if (score >= 80) return 'Accepted'.tr;
    if (score >= 50) return 'Review Required'.tr;
    return 'Rejected'.tr;
  }

  String _getCurrentSource() {
    final dynamic args = Get.arguments;
    return args is Map<String, dynamic> ? args['source']?.toString() ?? 'initiative_analysis' : 'initiative_analysis';
  }

  String _getHeaderTitle(String source) =>
      source == 'challenge_adjustment' ? 'adaptation'.tr : 'suggestion'.tr;

  String _getHeaderHighlight(String source) =>
      source == 'challenge_adjustment' ? 'analysis'.tr : 'of_initiatives'.tr;

  String _getAnalysisTitle(String source) =>
      source == 'challenge_adjustment' ? 'Adaptation Analysis Results' : 'Initiative Analysis Results';

  // =========================================================================
  // BUILD
  // =========================================================================
  @override
  Widget build(BuildContext context) {
    final double sw = MediaQuery.of(context).size.width;
    final double sh = MediaQuery.of(context).size.height;
    return sw < 768
        ? _buildMobileLayout(context, sw, sh)
        : _buildDesktopLayout(context, sw, sh);
  }

  Widget _buildMobileLayout(BuildContext context, double sw, double sh) {
    return Scaffold(
      body: CustomBackground(
        child: SafeArea(
          child: Stack(
            children: [
              Positioned.fill(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: EdgeInsets.only(bottom: AppDimensions.d18.h),
                  child: _buildContent(sw, sh),
                ),
              ),
              Positioned(
                right: sw * -0.07,
                top: sh * 0.50,
                child: const CustomHomeNavBar(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDesktopLayout(BuildContext context, double sw, double sh) {
    final double containerWidth = sw > 1200 ? 720.0 : sw * 0.72;

    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Opacity(
              opacity: 0.1,
              child: Image.asset('assets/images/web_background.png', fit: BoxFit.cover),
            ),
          ),
          Positioned(
            top: 0, left: 0, right: 0,
            child: DesktopAppBar(
              screenWidth: sw, screenHeight: sh,
              title: _getHeaderTitle(_getCurrentSource()),
              subtitle: _getHeaderHighlight(_getCurrentSource()),
            ),
          ),
          Positioned(
            top: 110, left: 0, right: 0, bottom: 80,
            child: Center(
              child: Container(
                width: containerWidth,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 20, spreadRadius: 4, offset: const Offset(0, 8))],
                ),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(36),
                  child: _buildContent(sw, sh),
                ),
              ),
            ),
          ),
          Positioned(
            bottom: 20, left: 0,
            child: GestureDetector(
              onTap: () => Get.back(),
              child: CustomSvg(assetPath: 'assets/images/left.svg', semanticsLabel: ''),
            ),
          ),
          Positioned(
            bottom: 20, left: 0, right: -30,
            child: Center(child: const CustomHomeNavBar()),
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // SHARED CONTENT
  // =========================================================================
  Widget _buildContent(double sw, double sh) {
    return Obx(() {
      final parsed = _parseArguments();
      final bool isHighScore   = parsed.score >= 80;
      final bool isMediumScore = parsed.score >= 50 && parsed.score < 80;
      final bool isAccepted    = _isDecisionAccepted(parsed.decision);

      return Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(height: sw >= 768 ? 16.0 : sh * 0.03),

          if (sw < 768)
            CustomHeader(
              title: _getHeaderTitle(parsed.source),
              highlightedText: _getHeaderHighlight(parsed.source),
              subtitle: '',
              onBackTap: () => Get.back(),
            )
          else
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(
                _getAnalysisTitle(parsed.source),
                style: TextStyle(
                  fontSize: _fs(sw, 20, tablet: 18, desktop: 18),
                  fontWeight: FontWeight.w600,
                  color: AppColors.primaryBlue,
                ),
                textAlign: TextAlign.center,
              ),
            ),

          SizedBox(height: sw >= 768 ? 20.0 : sh * 0.02),

          if (_viewModel.isSubmitting.value)
            _buildLoadingCard(sw)
          else if (parsed.hasData)
            _buildAnalysisContainer(
              sw: sw,
              percentage: parsed.score,
              decision: parsed.decision,
              explanation: parsed.explanation,
              isAccepted: isAccepted,
              isHighScore: isHighScore,
              isMediumScore: isMediumScore,
              source: parsed.source,
            )
          else
            _buildLoadingCard(sw),

          SizedBox(height: sw >= 768 ? 20.0 : sh * 0.02),

          Padding(
            padding: EdgeInsets.symmetric(horizontal: sw >= 768 ? 0 : 20.w),
            child: _buildNavigationButton(
              sw: sw,
              source: parsed.source,
              hasData: parsed.hasData,
              decision: parsed.decision,
              isAccepted: isAccepted,
            ),
          ),

          SizedBox(height: sw >= 768 ? 16.0 : sh * 0.001),
        ],
      );
    });
  }

  // =========================================================================
  // ANALYSIS CONTAINER
  // =========================================================================
  Widget _buildAnalysisContainer({
    required double sw,
    required int percentage,
    required String decision,
    required String explanation,
    required bool isAccepted,
    required bool isHighScore,
    required bool isMediumScore,
    required String source,
  }) {
    final Color containerColor = isHighScore
        ? const Color(0xff8DC046)
        : isMediumScore ? Colors.orange : Colors.red.shade400;
    final IconData statusIcon = isHighScore
        ? Icons.sentiment_very_satisfied
        : isMediumScore ? Icons.sentiment_neutral : Icons.sentiment_dissatisfied;

    final double robotSize = sw >= 1024 ? 72.0 : sw >= 768 ? 80.0 : 100.h;
    final double hPad      = sw >= 768 ? 0 : 16.w;
    final double borderRad = _dr(sw, 24);
    final double innerRad  = _dr(sw, 16);

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: hPad),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: const Color(0xff8DC046),
          borderRadius: BorderRadius.circular(borderRad),
        ),
        child: Column(
          children: [
            // Robot + title
            Container(
              decoration: BoxDecoration(
                color: const Color(0xff8DC046),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(borderRad),
                  topRight: Radius.circular(borderRad),
                ),
              ),
              padding: EdgeInsets.symmetric(vertical: _dh(sw, 32), horizontal: _d(sw, 20)),
              child: Column(
                children: [
                  Image.asset('assets/images/robort.png', height: robotSize, width: robotSize),
                  SizedBox(height: _dh(sw, 8)),
                  Text(_getAnalysisTitle(source),
                      style: TextStyle(color: Colors.white, fontSize: _fs(sw, 18, tablet: 16, desktop: 16), fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center),
                  if (!isAccepted) ...[
                    SizedBox(height: _dh(sw, 8)),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: _d(sw, 12), vertical: _dh(sw, 4)),
                      decoration: BoxDecoration(color: Colors.red.shade600, borderRadius: BorderRadius.circular(_dr(sw, 12))),
                      child: Text('${'retry'.tr} $_currentRetry ${'of'.tr} $_maxRetries',
                          style: TextStyle(color: Colors.white, fontSize: _fs(sw, 12, desktop: 11), fontWeight: FontWeight.w600)),
                    ),
                  ],
                ],
              ),
            ),

            // Percentage
            Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(vertical: _dh(sw, 16)),
              decoration: const BoxDecoration(color: Color(0xffC8CD37)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(statusIcon, color: Colors.black, size: sw >= 768 ? 26.0 : 32.sp),
                  SizedBox(width: _d(sw, 12)),
                  Text('$percentage%',
                      style: TextStyle(color: Colors.black, fontSize: _fs(sw, 32, tablet: 28, desktop: 26), fontWeight: FontWeight.bold)),
                ],
              ),
            ),

            // Threshold
            Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(vertical: _dh(sw, 12)),
              decoration: const BoxDecoration(color: Color(0xffC8CD37)),
              child: Text('${_safeTranslate('relevance_threshold')}: >80%',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black, fontSize: _fs(sw, 14, tablet: 13, desktop: 12), fontWeight: FontWeight.w500)),
            ),

            // Explanation card
            Padding(
              padding: EdgeInsets.all(_d(sw, 16)),
              child: Container(
                width: double.infinity,
                padding: EdgeInsets.all(_d(sw, 20)),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(innerRad)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: EdgeInsets.all(_d(sw, 8)),
                          decoration: BoxDecoration(color: containerColor.withOpacity(0.2), shape: BoxShape.circle),
                          child: Icon(isAccepted ? Icons.lightbulb : Icons.warning_amber_rounded,
                              color: containerColor, size: sw >= 768 ? 24.0 : 24.sp),
                        ),
                        SizedBox(width: _d(sw, 12)),
                        Expanded(
                          child: Text(decision,
                              style: TextStyle(color: Colors.black87, fontSize: _fs(sw, 20, tablet: 16, desktop: 15), fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                    SizedBox(height: _dh(sw, 16)),
                    Text(explanation,
                        style: TextStyle(color: Colors.black54, fontSize: _fs(sw, 15, tablet: 13, desktop: 13), height: 1.5)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // =========================================================================
  // LOADING CARD
  // =========================================================================
  Widget _buildLoadingCard(double sw) {
    final double robotSize = sw >= 1024 ? 72.0 : sw >= 768 ? 80.0 : 100.h;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: sw >= 768 ? 0 : 16.w),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(_d(sw, 40)),
        decoration: BoxDecoration(
          color: const Color(0xFFBFD200),
          borderRadius: BorderRadius.circular(_dr(sw, 24)),
        ),
        child: Column(
          children: [
            Image.asset('assets/images/robort.png', height: robotSize, width: robotSize),
            SizedBox(height: _dh(sw, 20)),
            const CircularProgressIndicator(color: Colors.white, strokeWidth: 3),
            SizedBox(height: _dh(sw, 20)),
            Text(
              _viewModel.isSubmitting.value
                  ? 'Running Adaptation Analysis...'
                  : _safeTranslate('loading_analysis', fallback: 'Analyzing initiatives...'),
              style: TextStyle(color: Colors.white, fontSize: _fs(sw, 16, tablet: 14, desktop: 14), fontWeight: FontWeight.w600),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // =========================================================================
  // NAVIGATION BUTTON — exact logic from AIAnalysisShowScreen
  // =========================================================================
  Widget _buildNavigationButton({
    required double sw,
    required String source,
    required bool hasData,
    required String decision,
    required bool isAccepted,
  }) {
    if (_viewModel.isSubmitting.value) {
      return SizedBox(width: double.infinity,
          child: CustomButton(text: 'analyzing'.tr, onPressed: () {}));
    }

    if (!isAccepted) {
      return SizedBox(
        width: double.infinity,
        child: CustomButton(
          text: 'try_again'.tr,
          backgroundColor: AppColors.primaryRed,
          onPressed: () => _navigateBasedOnDecisionAndMode(
              decision: decision, source: source, hasData: hasData),
        ),
      );
    }

    switch (source) {
      case 'initiative_analysis':
        return SizedBox(
          width: double.infinity,
          child: CustomButton(
            text: 'check_contextual_challenge'.tr,
            onPressed: hasData
                ? () => Get.toNamed(AppRoutes.contextualChallenge, arguments: {
              'analysisData': Get.arguments,
              'source': 'initiative_analysis',
            })
                : () {},
          ),
        );
      case 'challenge_adjustment':
        return SizedBox(
          width: double.infinity,
          child: CustomButton(
            text: 'proceed_to_results'.tr,
            onPressed: () => _navigateBasedOnDecisionAndMode(
                decision: decision, source: source, hasData: hasData),
          ),
        );
      default:
        return SizedBox(
          width: double.infinity,
          child: CustomButton(
            text: 'continue'.tr,
            onPressed: () => _navigateBasedOnDecisionAndMode(
                decision: decision, source: source, hasData: hasData),
          ),
        );
    }
  }
}

class _ParsedAnalysis {
  final EvaluateInitiativeModel? evaluationData;
  final String source;
  final int score;
  final String decision;
  final String explanation;
  final bool hasData;

  const _ParsedAnalysis({
    required this.evaluationData,
    required this.source,
    required this.score,
    required this.decision,
    required this.explanation,
    required this.hasData,
  });
}








// import 'dart:convert';
// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:flutter_svg/flutter_svg.dart';
// import 'package:get/get.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// import '../../../controllers/custom_ai_startegy_controller.dart';
// import '../../../core/app_colors.dart';
// import '../../../core/app_dimensions.dart';
// import '../../../data/network/network_api_services.dart';
// import '../../../data/response/api_response.dart';
// import '../../../generated/models/requests/adaptation_analysis_model.dart';
// import '../../../generated/models/responses/evaluate_initiative/evaluate_initiative_model.dart';
// import '../../../services/shared_preference.dart';
// import '../../../utils/snackbar_helper.dart';
// import '../../../view_model/challange_view_models/adaptation_ai_analysis-viewmodel.dart';
// import '../../routes/app_routes.dart';
// import '../../widgets/custom_button.dart';
// import '../../widgets/custom_button2.dart';
// import '../../widgets/custom_home_navbar.dart';
// import '../../widgets/custom_svg.dart';
// import '../../widgets/screens_unique_parts/custom_background.dart';
// import '../../widgets/screens_unique_parts/custom_header.dart';
// import '../../widgets/Website/desktop_appbar.dart';
//
// class AIAnalysisScreen extends StatefulWidget {
//   const AIAnalysisScreen({super.key});
//
//   @override
//   State<AIAnalysisScreen> createState() => _AIAnalysisScreenState();
// }
//
// class _AIAnalysisScreenState extends State<AIAnalysisScreen> {
//   final AdaptationAIAnalysisViewModel _viewModel = Get.find();
//   final int _maxRetries = 3;
//   int _currentRetry = 0;
//   bool _isNavigating = false;
//
//   // ── Adaptive font helper ───────────────────────────────────────────────────
//   // Plain logical px on desktop/tablet — .sp only on mobile.
//   static double _fs(double screenWidth, double mobile,
//       {double? tablet, double? desktop}) {
//     if (screenWidth >= 1024) return desktop ?? tablet ?? mobile - 2;
//     if (screenWidth >= 768) return tablet ?? mobile - 1;
//     return mobile.sp;
//   }
//
//   // ── Adaptive dimension helpers ─────────────────────────────────────────────
//   // Use plain px on desktop/tablet, ScreenUtil on mobile.
//   static double _w(double screenWidth, double value) =>
//       screenWidth >= 768 ? value : value.w;
//   static double _h(double screenWidth, double value) =>
//       screenWidth >= 768 ? value : value.h;
//   static double _r(double screenWidth, double value) =>
//       screenWidth >= 768 ? value : value.r;
//
//   String _safeTranslate(String? key, {String fallback = ''}) {
//     if (key == null) return fallback;
//     try {
//       return key.tr;
//     } catch (e) {
//       return fallback;
//     }
//   }
//
//   void _loadRetryCount() async {
//     try {
//       final prefs = await SharedPreferences.getInstance();
//       _currentRetry = prefs.getInt('analysis_retry_count') ?? 0;
//     } catch (e) {
//       _currentRetry = 0;
//     }
//   }
//
//   void _saveRetryCount() async {
//     try {
//       final prefs = await SharedPreferences.getInstance();
//       await prefs.setInt('analysis_retry_count', _currentRetry);
//     } catch (e) {
//       debugPrint('❌ Error saving retry count: $e');
//     }
//   }
//
//   void _resetRetryCount() async {
//     try {
//       final prefs = await SharedPreferences.getInstance();
//       await prefs.setInt('analysis_retry_count', 0);
//       _currentRetry = 0;
//     } catch (e) {
//       debugPrint('❌ Error resetting retry count: $e');
//     }
//   }
//
//   void _handleAnalysisBasedOnSource() async {
//     try {
//       final dynamic arguments = Get.arguments;
//       final source = arguments is Map<String, dynamic>
//           ? arguments['source'] ?? ''
//           : '';
//       final adaptationRequest = arguments is Map<String, dynamic>
//           ? arguments['adaptationRequest']
//           : null;
//
//       if (source == 'challenge_adjustment' && adaptationRequest != null) {
//         await _runAdaptationAnalysis(adaptationRequest);
//       }
//     } catch (e) {
//       debugPrint('❌ Error in analysis handling: $e');
//     }
//   }
//
//   Future<void> _runAdaptationAnalysis(dynamic adaptationRequest) async {
//     try {
//       if (adaptationRequest is AdaptationAnalysisRequest) {
//         await _viewModel.submitAdaptationAnalysis(
//           strategy: adaptationRequest.strategy,
//           objective: adaptationRequest.objective,
//           keyResult: adaptationRequest.keyResult,
//           challenge: adaptationRequest.challenge,
//           proposal: adaptationRequest.proposal ?? 'Strategic adaptations',
//         );
//       } else if (adaptationRequest is Map<String, dynamic>) {
//         await _viewModel.submitAdaptationAnalysis(
//           strategy: adaptationRequest['strategy']?.toString() ??
//               await _getDefaultStrategy(),
//           objective: adaptationRequest['objective']?.toString() ??
//               await _getDefaultObjective(),
//           keyResult:
//           adaptationRequest['keyResult']?.toString() ?? 'Adapted Key Result',
//           challenge:
//           adaptationRequest['challenge']?.toString() ?? 'Market Challenge',
//           proposal: adaptationRequest['proposal']?.toString() ??
//               'Strategic adaptations',
//         );
//       } else {
//         await _viewModel.submitAdaptationAnalysis(
//           strategy: await _getDefaultStrategy(),
//           objective: await _getDefaultObjective(),
//           keyResult: 'Adapted Key Result',
//           challenge: 'Market Challenge',
//           proposal: 'Strategic adaptations to address market changes',
//         );
//       }
//     } catch (e) {
//       debugPrint('❌ Error running adaptation analysis: $e');
//     }
//   }
//
//   Future<String> _getDefaultStrategy() async {
//     try {
//       final strategyData = await SharedPrefs.getSelectedStrategy();
//       return strategyData?['title']?.toString() ?? 'CEO Strategy';
//     } catch (e) {
//       return 'CEO Strategy';
//     }
//   }
//
//   Future<String> _getDefaultObjective() async {
//     try {
//       final objectiveData = await SharedPrefs.getSelectedObjective();
//       return objectiveData?['title']?.toString() ?? 'Business Growth Objective';
//     } catch (e) {
//       return 'Business Growth Objective';
//     }
//   }
//
//   void _navigateBasedOnDecisionAndMode({
//     required String decision,
//     required String source,
//     required bool hasData,
//   }) async {
//     if (_isNavigating) return;
//     _isNavigating = true;
//
//     try {
//       final savedMode = await SharedPrefs.getGameMode() ?? 'solo';
//       final isDecisionAccepted = _isDecisionAccepted(decision);
//
//       if (!isDecisionAccepted) {
//         _currentRetry++;
//         _saveRetryCount();
//
//         if (_currentRetry >= _maxRetries) {
//           await _showMaxRetriesDialog();
//           _resetRetryCount();
//           _navigateToHomeScreen();
//         } else {
//           await _showRetryDialog();
//         }
//         return;
//       }
//
//       _resetRetryCount();
//       await _proceedWithAcceptedDecision(savedMode, source);
//     } catch (e) {
//       Get.snackbar('Navigation Error', 'Failed to navigate: ${e.toString()}',
//           backgroundColor: Colors.red, colorText: Colors.white);
//     } finally {
//       _isNavigating = false;
//     }
//   }
//
//   bool _isDecisionAccepted(String decision) {
//     final lowerDecision = decision.toLowerCase();
//     return lowerDecision.contains('accepted') ||
//         lowerDecision.contains('approved') ||
//         (lowerDecision.contains('review') &&
//             !lowerDecision.contains('rejected'));
//   }
// // ── ADAPTIVE DIALOG HELPER ─────────────────────────────────────────────────
//   // Call this instead of Get.dialog directly so sizing is always correct.
//   void _showAdaptiveDialog({
//     required String title,
//     required String content,
//     required List<Widget> actions,
//   }) {
//     final double screenWidth = MediaQuery.of(Get.context!).size.width;
//     final double screenHeight = MediaQuery.of(Get.context!).size.height;
//
//     final bool isDesktop = screenWidth >= 1024;
//     final bool isTablet = screenWidth >= 768 && screenWidth < 1024;
//
//     // Dialog width: constrained on desktop, near full on mobile
//     final double dialogWidth = isDesktop
//         ? 420.0
//         : isTablet
//         ? 380.0
//         : screenWidth * 0.88;
//
//     // Font sizes — plain px on desktop/tablet, logical sp on mobile
//     final double titleSize =
//     isDesktop ? 16.0 : isTablet ? 15.5 : 16.sp;
//     final double bodySize =
//     isDesktop ? 13.0 : isTablet ? 13.0 : 14.sp;
//     final double buttonSize =
//     isDesktop ? 13.0 : isTablet ? 13.0 : 14.sp;
//
//     final double titlePadding = isDesktop ? 20.0 : 20.0;
//     final double contentPadding = isDesktop ? 16.0 : 16.0;
//     final double actionPadding = isDesktop ? 8.0 : 8.0;
//     final double borderRadius = isDesktop ? 14.0 : 16.0;
//
//     Get.dialog(
//       Dialog(
//         shape: RoundedRectangleBorder(
//           borderRadius: BorderRadius.circular(borderRadius),
//         ),
//         child: Container(
//           width: dialogWidth,
//           padding: EdgeInsets.zero,
//           decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.circular(borderRadius),
//           ),
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             crossAxisAlignment: CrossAxisAlignment.stretch,
//             children: [
//               // ── Title ────────────────────────────────────────────────────
//               Padding(
//                 padding: EdgeInsets.fromLTRB(
//                     titlePadding, titlePadding, titlePadding, 8),
//                 child: Text(
//                   title,
//                   style: TextStyle(
//                     fontSize: titleSize,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.black87,
//                     fontFamily: 'GothamBold',
//                   ),
//                 ),
//               ),
//
//               // ── Divider ───────────────────────────────────────────────────
//               Divider(height: 1, color: Colors.grey.withOpacity(0.2)),
//
//               // ── Content ───────────────────────────────────────────────────
//               Padding(
//                 padding: EdgeInsets.fromLTRB(
//                     contentPadding, 14, contentPadding, 14),
//                 child: Text(
//                   content,
//                   style: TextStyle(
//                     fontSize: bodySize,
//                     color: Colors.black54,
//                     height: 1.5,
//                     fontFamily: 'Gotham',
//                   ),
//                 ),
//               ),
//
//               // ── Divider ───────────────────────────────────────────────────
//               Divider(height: 1, color: Colors.grey.withOpacity(0.2)),
//
//               // ── Actions ───────────────────────────────────────────────────
//               Padding(
//                 padding: EdgeInsets.symmetric(
//                     horizontal: actionPadding, vertical: 6),
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.end,
//                   children: actions
//                       .map((action) => DefaultTextStyle(
//                     style: TextStyle(
//                       fontSize: buttonSize,
//                       fontWeight: FontWeight.w600,
//                       color: AppColors.primaryRed,
//                       fontFamily: 'GothamBold',
//                     ),
//                     child: action,
//                   ))
//                       .toList(),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//       barrierDismissible: false,
//     );
//   }
//
//   // ── RETRY DIALOG ───────────────────────────────────────────────────────────
//   Future<void> _showRetryDialog() async {
//     _showAdaptiveDialog(
//       title: 'initiative_rejected'.tr,
//       content: '${'initiative_needs_improvement'.tr}\n\n'
//           '${'retry_count'.tr}: $_currentRetry/$_maxRetries\n'
//           '${'suggest_improve_initiatives'.tr}',
//       actions: [
//         TextButton(
//           onPressed: () {
//             Get.back();
//             _navigateToKeyObjectiveScreen();
//           },
//           child: Text('try_again'.tr),
//         ),
//       ],
//     );
//   }
//
//   // ── MAX RETRIES DIALOG ─────────────────────────────────────────────────────
//   Future<void> _showMaxRetriesDialog() async {
//     _showAdaptiveDialog(
//       title: 'max_retries_reached'.tr,
//       content:
//       '${'max_retries_exceeded'.tr}\n\n${'returning_to_home_screen'.tr}',
//       actions: [
//         TextButton(
//           onPressed: () => Get.back(),
//           child: Text('understand'.tr),
//         ),
//       ],
//     );
//   }
//   // Future<void> _showRetryDialog() async {
//   //   await Get.dialog(
//   //     AlertDialog(
//   //       title: Text('initiative_rejected'.tr),
//   //       content: Text(
//   //         '${'initiative_needs_improvement'.tr}\n\n'
//   //             '${'retry_count'.tr}: $_currentRetry/$_maxRetries\n'
//   //             '${'suggest_improve_initiatives'.tr}',
//   //       ),
//   //       actions: [
//   //         TextButton(
//   //           onPressed: () {
//   //             Get.back();
//   //             _navigateToKeyObjectiveScreen();
//   //           },
//   //           child: Text('try_again'.tr),
//   //         ),
//   //       ],
//   //     ),
//   //     barrierDismissible: false,
//   //   );
//   // }
//   //
//   // Future<void> _showMaxRetriesDialog() async {
//   //   await Get.dialog(
//   //     AlertDialog(
//   //       title: Text('max_retries_reached'.tr),
//   //       content: Text(
//   //           '${'max_retries_exceeded'.tr}\n\n${'returning_to_home_screen'.tr}'),
//   //       actions: [
//   //         TextButton(
//   //           onPressed: () => Get.back(),
//   //           child: Text('understand'.tr),
//   //         ),
//   //       ],
//   //     ),
//   //     barrierDismissible: false,
//   //   );
//   // }
//
//   void _navigateToKeyObjectiveScreen() {
//     Get.offAllNamed(
//       AppRoutes.keyObjectiveScreen,
//       parameters: {'isRetry': 'true'},
//       arguments: Get.arguments,
//     );
//   }
//
//   void _navigateToHomeScreen() {
//     Get.offAllNamed(AppRoutes.home);
//     Future.delayed(const Duration(milliseconds: 500), () {
//       SnackbarHelper.info(
//           'You have completed all 3 attempts. Please try again with a new strategy!');
//     });
//   }
//
//   Future<void> _proceedWithAcceptedDecision(
//       String savedMode, String source) async {
//     switch (savedMode) {
//       case 'solo':
//         Get.offAllNamed(AppRoutes.gameCompleteScreen);
//         break;
//       case 'challenge':
//         await _navigateChallengeMode();
//         break;
//       case 'campaign':
//         await _navigateCampaignMode(source);
//         break;
//       default:
//         Get.offAllNamed(AppRoutes.gameCompleteScreen);
//         break;
//     }
//   }
//
//   Future<void> _navigateChallengeMode() async {
//     final challengeId = await SharedPrefs.getChallengeId();
//     final userId = SharedPrefs.getUserId();
//     if (challengeId == null ||
//         challengeId.isEmpty ||
//         userId == null ||
//         userId.isEmpty) {
//       Get.snackbar('Error', 'Challenge data not found',
//           backgroundColor: Colors.red, colorText: Colors.white);
//       return;
//     }
//   }
//
//   Future<void> _navigateCampaignMode(String source) async {
//     Get.offAllNamed(AppRoutes.campaignModeScreen);
//   }
//
//   Future<int> _getCurrentCampaignLevel() async {
//     try {
//       final levelStr = await SharedPrefs.getString('current_campaign_level');
//       return int.tryParse(levelStr ?? '1') ?? 1;
//     } catch (e) {
//       return 1;
//     }
//   }
//
//   // ── BUILD ──────────────────────────────────────────────────────────────────
//
//   @override
//   Widget build(BuildContext context) {
//     final double screenWidth = MediaQuery.of(context).size.width;
//     final double screenHeight = MediaQuery.of(context).size.height;
//     final bool isMobile = screenWidth < 768;
//
//     return isMobile
//         ? _buildMobileLayout(context, screenWidth, screenHeight)
//         : _buildDesktopWebLayout(context, screenWidth, screenHeight);
//   }
//
//   // ── MOBILE ─────────────────────────────────────────────────────────────────
//   Widget _buildMobileLayout(
//       BuildContext context, double screenWidth, double screenHeight) {
//     return Scaffold(
//       body: CustomBackground(
//         child: SafeArea(
//           child: Stack(
//             children: [
//               Positioned.fill(
//                 child: SingleChildScrollView(
//                   physics: const BouncingScrollPhysics(),
//                   padding: EdgeInsets.only(bottom: AppDimensions.d18.h),
//                   child: _buildContent(screenWidth, screenHeight),
//                 ),
//               ),
//               Positioned(
//                 right: screenWidth * -0.07,
//                 top: screenHeight * 0.50,
//                 child: const CustomHomeNavBar(),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   // ── DESKTOP ────────────────────────────────────────────────────────────────
//   Widget _buildDesktopWebLayout(
//       BuildContext context, double screenWidth, double screenHeight) {
//     final double containerWidth =
//     screenWidth > 1200 ? 720.0 : screenWidth * 0.72;
//
//     return Scaffold(
//       body: Stack(
//         children: [
//           // Background image
//           Positioned.fill(
//             child: Opacity(
//               opacity: 0.1,
//               child: Image.asset('assets/images/web_background.png',
//                   fit: BoxFit.cover),
//             ),
//           ),
//
//           // Desktop AppBar
//           Positioned(
//             top: 0,
//             left: 0,
//             right: 0,
//             child: DesktopAppBar(
//               screenWidth: screenWidth,
//               screenHeight: screenHeight,
//               title: _getHeaderTitle(_getCurrentSource()),
//               subtitle: _getHeaderHighlight(_getCurrentSource()),
//             ),
//           ),
//
//           // Centered white card
//           Positioned(
//             top: 110,
//             left: 0,
//             right: 0,
//             bottom: 80,
//             child: Center(
//               child: Container(
//                 width: containerWidth,
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   borderRadius: BorderRadius.circular(20),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.black.withOpacity(0.1),
//                       blurRadius: 20,
//                       spreadRadius: 4,
//                       offset: const Offset(0, 8),
//                     ),
//                   ],
//                 ),
//                 child: SingleChildScrollView(
//                   physics: const BouncingScrollPhysics(),
//                   padding: const EdgeInsets.all(36),
//                   child: _buildContent(screenWidth, screenHeight),
//                 ),
//               ),
//             ),
//           ),
//
//           // Back SVG
//           Positioned(
//             bottom: 20,
//             left: 0,
//             child: GestureDetector(
//               onTap: () => Get.back(),
//               child: CustomSvg(
//                 assetPath: 'assets/images/left.svg',
//                 semanticsLabel: '',
//               ),
//             ),
//           ),
//
//           // Home NavBar
//           Positioned(
//             bottom: 20,
//             left: 0,
//             right: -30,
//             child: Center(child: const CustomHomeNavBar()),
//           ),
//         ],
//       ),
//     );
//   }
//
//   // ── SHARED CONTENT (used by both layouts) ──────────────────────────────────
//   Widget _buildContent(double screenWidth, double screenHeight) {
//     return Obx(() {
//       final dynamic arguments = Get.arguments;
//
//       EvaluateInitiativeModel? evaluationData;
//       String source = 'initiative_analysis';
//
//       if (arguments is EvaluateInitiativeModel) {
//         evaluationData = arguments;
//         source = 'initiative_analysis';
//       } else if (arguments is Map<String, dynamic>) {
//         if (_viewModel.evaluationData.value != null) {
//           final adaptationData = _viewModel.evaluationData.value!;
//           evaluationData = EvaluateInitiativeModel(
//             score: adaptationData.score,
//             decision: _getDecisionFromScore(adaptationData.score),
//             explanation: adaptationData.feedback,
//           );
//           source = 'challenge_adjustment';
//         } else if (arguments['analysisData'] != null) {
//           evaluationData = arguments['analysisData'];
//           source = arguments['source'] ?? 'challenge_adjustment';
//         }
//       }
//
//       final bool hasData =
//           evaluationData != null || _viewModel.evaluationData.value != null;
//       final int score = evaluationData?.score ??
//           _viewModel.evaluationData.value?.score ?? 0;
//       final String decision =
//           evaluationData?.decision ?? _getDecisionFromScore(score);
//       final String explanation = evaluationData?.explanation ??
//           _viewModel.evaluationData.value?.feedback ??
//           'No analysis available';
//       final bool isAccepted = _isDecisionAccepted(decision);
//       final bool isHighScore = score >= 80;
//       final bool isMediumScore = score >= 50 && score < 80;
//
//       return Column(
//         crossAxisAlignment: CrossAxisAlignment.center,
//         children: [
//           SizedBox(height: screenWidth >= 768 ? 16 : screenHeight * 0.02),
//
//           // Header (mobile only — desktop uses DesktopAppBar)
//           if (screenWidth < 768)
//             CustomHeader(
//               title: _getHeaderTitle(source),
//               highlightedText: _getHeaderHighlight(source),
//               onBackTap: () => Get.back(),
//             )
//           else
//             _buildDesktopHeader(source, screenWidth),
//
//           SizedBox(height: screenWidth >= 768 ? 24 : screenHeight * 0.02),
//
//           if (_viewModel.isSubmitting.value)
//             _buildLoadingCard(screenWidth)
//           else if (hasData)
//             _buildAnalysisContainer(
//               screenWidth: screenWidth,
//               percentage: score,
//               decision: decision,
//               explanation: explanation,
//               isAccepted: isAccepted,
//               isHighScore: isHighScore,
//               isMediumScore: isMediumScore,
//               source: source,
//             )
//           else
//             _buildLoadingCard(screenWidth),
//
//           SizedBox(height: screenWidth >= 768 ? 24 : screenHeight * 0.02),
//
//           _buildNavigationButton(
//             screenWidth: screenWidth,
//             source: source,
//             hasData: hasData,
//             decision: decision,
//             isAccepted: isAccepted,
//           ),
//
//           SizedBox(height: screenWidth >= 768 ? 16 : screenHeight * 0.02),
//         ],
//       );
//     });
//   }
//
//   // ── DESKTOP HEADER ─────────────────────────────────────────────────────────
//   Widget _buildDesktopHeader(String source, double screenWidth) {
//     return Column(
//       children: [
//         Text(
//           _getHeaderTitle(source),
//           style: TextStyle(
//             // ✅ Plain logical px — no .sp on desktop
//             fontSize: _fs(screenWidth, 22, tablet: 20, desktop: 20),
//             fontWeight: FontWeight.bold,
//             color: AppColors.primaryBlue,
//           ),
//         ),
//         const SizedBox(height: 6),
//         Text(
//           _getHeaderHighlight(source),
//           style: TextStyle(
//             fontSize: _fs(screenWidth, 18, tablet: 16, desktop: 16),
//             fontWeight: FontWeight.w600,
//             color: AppColors.primaryGreen,
//           ),
//         ),
//       ],
//     );
//   }
//
//   // ── UNIFIED ANALYSIS CONTAINER ─────────────────────────────────────────────
//   Widget _buildAnalysisContainer({
//     required double screenWidth,
//     required int percentage,
//     required String decision,
//     required String explanation,
//     required bool isAccepted,
//     required bool isHighScore,
//     required bool isMediumScore,
//     required String source,
//   }) {
//     Color containerColor;
//     IconData statusIcon;
//
//     if (isHighScore) {
//       containerColor = const Color(0xff8DC046);
//       statusIcon = Icons.sentiment_very_satisfied;
//     } else if (isMediumScore) {
//       containerColor = Colors.orange;
//       statusIcon = Icons.sentiment_neutral;
//     } else {
//       containerColor = Colors.red.shade400;
//       statusIcon = Icons.sentiment_dissatisfied;
//     }
//
//     // Robot size — plain px on desktop
//     final double robotSize =
//     screenWidth >= 1024 ? 72.0 : screenWidth >= 768 ? 80.0 : 100.h;
//     final double percentFontSize =
//     _fs(screenWidth, 32, tablet: 28, desktop: 26);
//     final double titleFontSize =
//     _fs(screenWidth, 18, tablet: 16, desktop: 16);
//     final double decisionFontSize =
//     _fs(screenWidth, 20, tablet: 16, desktop: 15);
//     final double bodyFontSize =
//     _fs(screenWidth, 15, tablet: 13, desktop: 13);
//     final double thresholdFontSize =
//     _fs(screenWidth, 14, tablet: 13, desktop: 12);
//     final double iconSize =
//     screenWidth >= 768 ? 24.0 : 24.sp;
//     final double statusIconSize =
//     screenWidth >= 768 ? 26.0 : 32.sp;
//
//     // Outer padding
//     final double hPad = screenWidth >= 768 ? 0 : 16.w;
//     final double innerPad = _w(screenWidth, 20);
//     final double cardPad = _w(screenWidth, screenWidth >= 768 ? 20 : 16);
//     final double borderRadius = _r(screenWidth, 24);
//
//     return Padding(
//       padding: EdgeInsets.symmetric(horizontal: hPad),
//       child: Container(
//         width: double.infinity,
//         decoration: BoxDecoration(
//           color: const Color(0xff8DC046),
//           borderRadius: BorderRadius.circular(borderRadius),
//         ),
//         child: Column(
//           children: [
//             // ── Robot + title ──────────────────────────────────────────────
//             Container(
//               decoration: BoxDecoration(
//                 color: const Color(0xff8DC046),
//                 borderRadius: BorderRadius.only(
//                   topLeft: Radius.circular(borderRadius),
//                   topRight: Radius.circular(borderRadius),
//                 ),
//               ),
//               padding: EdgeInsets.symmetric(
//                 vertical: _h(screenWidth, 28),
//                 horizontal: _w(screenWidth, 20),
//               ),
//               child: Column(
//                 children: [
//                   SvgPicture.asset(
//                     'assets/images/robot.svg',
//                     height: robotSize,
//                     width: robotSize,
//                   ),
//                   SizedBox(height: _h(screenWidth, 12)),
//                   Text(
//                     _getAnalysisTitle(source),
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: titleFontSize, // ✅ adaptive
//                       fontWeight: FontWeight.bold,
//                     ),
//                     textAlign: TextAlign.center,
//                   ),
//                   if (!isAccepted) ...[
//                     SizedBox(height: _h(screenWidth, 10)),
//                     Container(
//                       padding: EdgeInsets.symmetric(
//                         horizontal: _w(screenWidth, 12),
//                         vertical: _h(screenWidth, 4),
//                       ),
//                       decoration: BoxDecoration(
//                         color: Colors.red.shade600,
//                         borderRadius:
//                         BorderRadius.circular(_r(screenWidth, 12)),
//                       ),
//                       child: Text(
//                         '${'retry'.tr} $_currentRetry ${'of'.tr} $_maxRetries',
//                         style: TextStyle(
//                           color: Colors.white,
//                           fontSize: _fs(screenWidth, 12, desktop: 11),
//                           fontWeight: FontWeight.w600,
//                         ),
//                       ),
//                     ),
//                   ],
//                 ],
//               ),
//             ),
//
//             // ── Percentage bar ─────────────────────────────────────────────
//             Container(
//               width: double.infinity,
//               padding: EdgeInsets.symmetric(vertical: _h(screenWidth, 16)),
//               decoration: const BoxDecoration(color: Color(0xffC8CD37)),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Icon(statusIcon,
//                       color: Colors.black, size: statusIconSize),
//                   SizedBox(width: _w(screenWidth, 12)),
//                   Text(
//                     '$percentage%',
//                     style: TextStyle(
//                       color: Colors.black,
//                       fontSize: percentFontSize, // ✅ adaptive
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//
//             // ── Threshold bar ──────────────────────────────────────────────
//             Container(
//               width: double.infinity,
//               padding: EdgeInsets.symmetric(vertical: _h(screenWidth, 10)),
//               decoration: const BoxDecoration(color: Color(0xffC8CD37)),
//               child: Text(
//                 '${_safeTranslate('relevance_threshold')}: >80%',
//                 textAlign: TextAlign.center,
//                 style: TextStyle(
//                   color: Colors.black,
//                   fontSize: thresholdFontSize, // ✅ adaptive
//                   fontWeight: FontWeight.w500,
//                 ),
//               ),
//             ),
//
//             // ── Explanation card ───────────────────────────────────────────
//             Padding(
//               padding: EdgeInsets.all(innerPad),
//               child: Container(
//                 width: double.infinity,
//                 padding: EdgeInsets.all(cardPad),
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   borderRadius:
//                   BorderRadius.circular(_r(screenWidth, 16)),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.black.withOpacity(0.08),
//                       blurRadius: 8,
//                       offset: const Offset(0, 2),
//                     ),
//                   ],
//                 ),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Row(
//                       children: [
//                         Container(
//                           padding: EdgeInsets.all(_w(screenWidth, 8)),
//                           decoration: BoxDecoration(
//                             color: containerColor.withOpacity(0.2),
//                             shape: BoxShape.circle,
//                           ),
//                           child: Icon(
//                             isAccepted
//                                 ? Icons.lightbulb
//                                 : Icons.warning_amber_rounded,
//                             color: containerColor,
//                             size: iconSize, // ✅ adaptive
//                           ),
//                         ),
//                         SizedBox(width: _w(screenWidth, 12)),
//                         Expanded(
//                           child: Text(
//                             decision,
//                             style: TextStyle(
//                               color: Colors.black87,
//                               fontSize: decisionFontSize, // ✅ adaptive
//                               fontWeight: FontWeight.bold,
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                     SizedBox(height: _h(screenWidth, 14)),
//                     Text(
//                       explanation,
//                       style: TextStyle(
//                         color: Colors.black54,
//                         fontSize: bodyFontSize, // ✅ adaptive
//                         height: 1.6,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   // ── UNIFIED LOADING CARD ───────────────────────────────────────────────────
//   Widget _buildLoadingCard(double screenWidth) {
//     final double robotSize =
//     screenWidth >= 1024 ? 72.0 : screenWidth >= 768 ? 80.0 : 100.h;
//     final double hPad = screenWidth >= 768 ? 0 : 16.w;
//
//     return Padding(
//       padding: EdgeInsets.symmetric(horizontal: hPad),
//       child: Container(
//         width: double.infinity,
//         padding: EdgeInsets.all(_w(screenWidth, 36)),
//         decoration: BoxDecoration(
//           color: const Color(0xFFBFD200),
//           borderRadius: BorderRadius.circular(_r(screenWidth, 24)),
//         ),
//         child: Column(
//           children: [
//             SvgPicture.asset(
//               'assets/images/robot.svg',
//               height: robotSize,
//               width: robotSize,
//             ),
//             SizedBox(height: _h(screenWidth, 20)),
//             const CircularProgressIndicator(
//                 color: Colors.white, strokeWidth: 3),
//             SizedBox(height: _h(screenWidth, 20)),
//             Text(
//               _viewModel.isSubmitting.value
//                   ? 'Running Adaptation Analysis...'
//                   : _safeTranslate('loading_analysis',
//                   fallback: 'Analyzing initiatives...'),
//               style: TextStyle(
//                 color: Colors.white,
//                 // ✅ adaptive
//                 fontSize: _fs(screenWidth, 16, tablet: 14, desktop: 14),
//                 fontWeight: FontWeight.w600,
//               ),
//               textAlign: TextAlign.center,
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   // ── UNIFIED NAVIGATION BUTTON ──────────────────────────────────────────────
//   Widget _buildNavigationButton({
//     required double screenWidth,
//     required String source,
//     required bool hasData,
//     required String decision,
//     required bool isAccepted,
//   }) {
//     if (_viewModel.isSubmitting.value) {
//       return SizedBox(
//         width: double.infinity,
//         child: CustomButton(text: 'analyzing'.tr, onPressed: () {}),
//       );
//     }
//
//     if (!isAccepted) {
//       return SizedBox(
//         width: double.infinity,
//         child: CustomButton2(
//           text: 'try_again'.tr,
//           onPressed: () => _navigateBasedOnDecisionAndMode(
//             decision: decision,
//             source: source,
//             hasData: hasData,
//           ),
//           backgroundColor: AppColors.primaryRed,
//         ),
//       );
//     }
//
//     switch (source) {
//       case 'initiative_analysis':
//         return SizedBox(
//           width: double.infinity,
//           child: CustomButton(
//             text: 'check_contextual_challenge'.tr,
//             onPressed: hasData
//                 ? () => Get.toNamed(
//               AppRoutes.contextualChallenge,
//               arguments: {
//                 'analysisData': Get.arguments,
//                 'source': 'initiative_analysis',
//               },
//             )
//                 : () {},
//           ),
//         );
//       case 'challenge_adjustment':
//         return SizedBox(
//           width: double.infinity,
//           child: CustomButton(
//             text: 'proceed_to_results'.tr,
//             onPressed: () => _navigateBasedOnDecisionAndMode(
//               decision: decision,
//               source: source,
//               hasData: hasData,
//             ),
//           ),
//         );
//       default:
//         return SizedBox(
//           width: double.infinity,
//           child: CustomButton(
//             text: 'continue'.tr,
//             onPressed: () => _navigateBasedOnDecisionAndMode(
//               decision: decision,
//               source: source,
//               hasData: hasData,
//             ),
//           ),
//         );
//     }
//   }
//
//   // ── HELPERS ────────────────────────────────────────────────────────────────
//   String _getCurrentSource() {
//     final dynamic arguments = Get.arguments;
//     if (arguments is Map<String, dynamic>) {
//       return arguments['source'] ?? 'initiative_analysis';
//     }
//     return 'initiative_analysis';
//   }
//
//   String _getDecisionFromScore(int score) {
//     if (score >= 80) return 'Accepted'.tr;
//     if (score >= 50) return 'Review Required'.tr;
//     return 'Rejected'.tr;
//   }
//
//   String _getHeaderTitle(String source) {
//     switch (source) {
//       case 'challenge_adjustment':
//         return 'adaptation'.tr;
//       default:
//         return 'suggestion'.tr;
//     }
//   }
//
//   String _getHeaderHighlight(String source) {
//     switch (source) {
//       case 'challenge_adjustment':
//         return 'analysis'.tr;
//       default:
//         return 'of_initiatives'.tr;
//     }
//   }
//
//   String _getAnalysisTitle(String source) {
//     switch (source) {
//       case 'challenge_adjustment':
//         return 'Adaptation Analysis Results';
//       default:
//         return 'Initiative Analysis Results';
//     }
//   }
// }
//
//
