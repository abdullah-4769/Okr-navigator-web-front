import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import '../../core/app_colors.dart';

class CustomAIStrategyContainer extends StatelessWidget {
  final String mode; // 'solo' or 'team'
  const CustomAIStrategyContainer({super.key, this.mode = 'solo'});

  // ── Adaptive font helper ───────────────────────────────────────────────────
  // Uses actual SCREEN width (via MediaQuery) — not LayoutBuilder constraints —
  // so it works correctly even when nested inside a fixed-width card.
  static double _fs(double screenWidth, double mobile,
      {double? tablet, double? desktop}) {
    if (screenWidth >= 1024) return desktop ?? tablet ?? mobile - 2;
    if (screenWidth >= 768) return tablet ?? mobile - 1;
    return mobile.sp; // only mobile uses ScreenUtil
  }

  @override
  Widget build(BuildContext context) {
    // ✅ MediaQuery for true device width — not LayoutBuilder constraint width
    final double screenWidth = MediaQuery.of(context).size.width;

    final bool isMobile = screenWidth < 768;
    final bool isTablet = screenWidth >= 768 && screenWidth < 1024;
    final bool isDesktop = screenWidth >= 1024;

    final bool isTeam = mode == 'team';
    final Color color =
    isTeam ? AppColors.primaryBlue : AppColors.primaryRed;

    // ── Dimensions — plain logical px on desktop/tablet ──────────────────────
    final double containerWidth = isMobile
        ? screenWidth * 0.9
        : isTablet
        ? screenWidth * 0.7
        : 560.0;

    final double containerPadding =
    isMobile ? 20.0 : isTablet ? 28.0 : 32.0;

    final double robotSize =
    isMobile ? 60.0 : isTablet ? 70.0 : 80.0;

    final double iconSize =
    isMobile ? 28.0 : isTablet ? 32.0 : 36.0;

    // ── Font sizes — adaptive ─────────────────────────────────────────────────
    final double headerFontSize =
    _fs(screenWidth, 12, tablet: 13, desktop: 13);
    final double bodyFontSize =
    _fs(screenWidth, 12, tablet: 12, desktop: 12);
    final double captionFontSize =
    _fs(screenWidth, 10, tablet: 11, desktop: 11);

    return Center(
      child: Container(
        width: containerWidth,
        padding: EdgeInsets.all(containerPadding),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(isDesktop ? 14 : 16.r),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // ── Robot icon ─────────────────────────────────────────────────
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Image.asset(
                'assets/images/robort11.png',
                height: robotSize,
                width: robotSize,
                fit: BoxFit.contain,
              ),
            ),

            SizedBox(height: isDesktop ? 16.0 : 20.0),

            // ── Header ─────────────────────────────────────────────────────
            Text(
              'ai_strategic_analysis'.tr,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'Gotham-Bold',
                fontSize: headerFontSize, // ✅ adaptive — no .sp on desktop
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),

            SizedBox(height: isDesktop ? 18.0 : 24.0),

            // ── Inner white card ───────────────────────────────────────────
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(containerPadding * 0.45),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(isDesktop ? 10 : 12.r),
                border: Border.all(color: color.withOpacity(0.2)),
                boxShadow: [
                  BoxShadow(
                    color: color.withOpacity(0.1),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  // Analytics icon
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.1),
                      borderRadius:
                      BorderRadius.circular(isDesktop ? 7 : 8.r),
                    ),
                    child: Icon(
                      Icons.analytics_outlined,
                      size: iconSize, // ✅ plain px — no .sp
                      color: color,
                    ),
                  ),

                  SizedBox(height: isDesktop ? 14.0 : 16.0),

                  // Primary body text
                  Text(
                    'submit_initiatives_ai_analysis'.tr,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: bodyFontSize, // ✅ adaptive
                      fontWeight: FontWeight.w600,
                      color: AppColors.textSecondary,
                      fontFamily: 'Gotham',
                      height: 1.4,
                    ),
                  ),

                  SizedBox(height: isDesktop ? 10.0 : 12.0),

                  // Caption text
                  Text(
                    'feedback_will_appear_here'.tr,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: captionFontSize, // ✅ adaptive
                      color: AppColors.textSecondary.withOpacity(0.7),
                      fontFamily: 'Gotham',
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}




// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:get/get.dart';
// import '../../core/app_colors.dart';
//
// class CustomAIStrategyContainer extends StatelessWidget {
//   final String mode; // 'solo' or 'team'
//   const CustomAIStrategyContainer({super.key, this.mode = 'solo'});
//
//   @override
//   Widget build(BuildContext context) {
//     return LayoutBuilder(
//       builder: (context, constraints) {
//         final double screenWidth = constraints.maxWidth;
//         final double screenHeight = constraints.maxHeight;
//
//         final bool isMobile = screenWidth < 768;
//         final bool isTablet = screenWidth >= 768 && screenWidth < 1024;
//         final bool isDesktop = screenWidth >= 1024;
//
//         // Responsive font helpers
//         double headerFont(double mobile, double tablet, double desktop) =>
//             isMobile ? mobile : isTablet ? tablet : desktop;
//         double bodyFont(double mobile, double tablet, double desktop) =>
//             isMobile ? mobile : isTablet ? tablet : desktop;
//         double buttonFont(double mobile, double tablet, double desktop) =>
//             isMobile ? mobile : isTablet ? tablet : desktop;
//
//         double containerPadding() => isMobile ? 20 : isTablet ? 30 : 40;
//         double containerWidth() => isMobile
//             ? screenWidth * 0.9
//             : isTablet
//             ? screenWidth * 0.7
//             : 600;
//
//         final bool isTeam = mode == 'team';
//         final Color color = isTeam ? AppColors.primaryBlue : AppColors.primaryRed;
//
//         return Center(
//           child: Container(
//             width: containerWidth(),
//             padding: EdgeInsets.all(containerPadding()),
//             decoration: BoxDecoration(
//               color: color,
//               borderRadius: BorderRadius.circular(16.r),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.black.withOpacity(0.08),
//                   blurRadius: 12,
//                   offset: const Offset(0, 4),
//                 ),
//               ],
//             ),
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 // Robot Icon
//                 Container(
//                   padding: EdgeInsets.all(12),
//                   decoration: BoxDecoration(
//                     color: Colors.white.withOpacity(0.1),
//                     shape: BoxShape.circle,
//                   ),
//                   child: Image.asset(
//                     'assets/images/robort11.png',
//                     height: isMobile ? 60 : isTablet ? 70 : 90,
//                     width: isMobile ? 60 : isTablet ? 70 : 90,
//                     fit: BoxFit.contain,
//                   ),
//                 ),
//                 const SizedBox(height: 20),
//
//                 // Header
//                 Text(
//                   'ai_strategic_analysis'.tr,
//                   textAlign: TextAlign.center,
//                   style: TextStyle(
//                     fontFamily: 'Gotham-Bold',
//                     fontSize: headerFont(12, 14, 14).sp,
//                     color: Colors.white,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//                 const SizedBox(height: 24),
//
//                 // Inner white container
//                 Container(
//                   width: double.infinity,
//                   padding: EdgeInsets.all(containerPadding() * 0.4),
//                   decoration: BoxDecoration(
//                     color: Colors.white,
//                     borderRadius: BorderRadius.circular(12.r),
//                     border: Border.all(color: color.withOpacity(0.2)),
//                     boxShadow: [
//                       BoxShadow(
//                         color: color.withOpacity(0.1),
//                         blurRadius: 6,
//                         offset: const Offset(0, 2),
//                       ),
//                     ],
//                   ),
//                   child: Column(
//                     children: [
//                       Container(
//                         padding: const EdgeInsets.all(10),
//                         decoration: BoxDecoration(
//                           color: color.withOpacity(0.1),
//                           borderRadius: BorderRadius.circular(8.r),
//                         ),
//                         child: Icon(
//                           Icons.analytics_outlined,
//                           size: isMobile ? 28 : isTablet ? 34 : 40,
//                           color: color,
//                         ),
//                       ),
//                       const SizedBox(height: 16),
//
//                       Text(
//                         'submit_initiatives_ai_analysis'.tr,
//                         textAlign: TextAlign.center,
//                         style: TextStyle(
//                           fontSize: bodyFont(12, 12, 13).sp,
//                           fontWeight: FontWeight.w600,
//                           color: AppColors.textSecondary,
//                           fontFamily: 'Gotham',
//                           height: 1.4,
//                         ),
//                       ),
//                       const SizedBox(height: 12),
//
//                       Text(
//                         'feedback_will_appear_here'.tr,
//                         textAlign: TextAlign.center,
//                         style: TextStyle(
//                           fontSize: bodyFont(10, 11, 12).sp,
//                           color: AppColors.textSecondary.withOpacity(0.7),
//                           fontFamily: 'Gotham',
//                           height: 1.5,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         );
//       },
//     );
//   }
// }
